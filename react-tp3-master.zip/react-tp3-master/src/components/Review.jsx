import React from 'react'
import { useParams } from 'react-router-dom'
import db from '../api/db.json'
const Review = () => {
    const params = useParams()
    let review = null
    if (params.slug === 'random') {
        const randomNumber = Math.floor(Math.random() * db.reviews.length)
         review = db.reviews[randomNumber]
    }else{
         review = db.reviews.find((elem) => elem.slug === params.slug)
    }

    console.log(review)
    return(
        <section data-name="review">
                <h2>{review.designation}</h2>
                <h3>{review.title}</h3>
                <p>
                    Price : <b>{review.price} $</b>
                </p>
                <blockquote>
                    <p>
                        {review.description}
                    </p>
                    <p txt="r">
                        <i>- {review.taster_name}</i>
                    </p>
                </blockquote>
            </section>
    )
}
export default Review