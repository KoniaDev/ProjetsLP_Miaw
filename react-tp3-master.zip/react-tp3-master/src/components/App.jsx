import React from 'react'
import Review from './Review'
import ReviewList from './ReviewList'
import db from '../api/db.json'
import Layout from './Layout'
import {BrowserRouter, Routes, Route} from 'react-router-dom'
import NotFound from './NotFound'


const App = () => {
    return ( 
    <BrowserRouter>    
        <Layout>
        <Routes>
            <Route path='*' element={<NotFound />}/>
            <Route index={true} element={<ReviewList />}/>
            <Route path="/view/:slug" element={<Review/>}/>
        </Routes>
            {/*<ReviewList reviews={Reviews.reviews} />*/}
        </Layout>
    </BrowserRouter>
    )
}

export default App