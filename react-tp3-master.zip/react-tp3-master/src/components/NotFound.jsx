import React from 'react'
import {Link} from 'react-router-dom'

const NotFound = () => {
    return (
        <>
        <h2>Page non trouvée !</h2>
        <Link to='/'>Accueil</Link>
        </>
    )
}

export default NotFound