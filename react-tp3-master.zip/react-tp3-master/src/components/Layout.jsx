import React from 'react'
import logo from '../assets/logo.png'
import {Link} from 'react-router-dom'
const Layout = (props) => {
  return (
    <>
    <nav style={{ marginBottom: '50px' }}>
            <header>
                <Link to="/"><img src={logo} alt="React-Wines logo" /></Link>
            </header>
            <div>
                <ul>
                    <li>
                        <Link to='/'>Home</Link>
                    </li>
                    <li>
                        <Link to='/view/random'>Random</Link>
                    </li>
                    <li>
                        <Link to='/login'>Login</Link>
                    </li>
                </ul>
            </div>
        </nav>
        <main>
            {props.children}
        </main>
        <footer>
            <p>La Rochelle Université</p>
        </footer>
    </>
  )
}
export default Layout