//console.log(document.getElementsByTagName('h1')[0].textContent)
//console.log(document.getElementsByClassName('pcard').length)

const h1 = document.querySelector('h1').textContent
console.log(h1)

const cards = document.querySelectorAll('.pcard')
console.log(cards.length)

const cardsContainer = document.querySelector('.set-of-pcard')

//Modification du nom de la première card
console.log(cardsContainer.firstElementChild.querySelector('h2').textContent = 'Test')

console.log(cardsContainer.appendChild(cardsContainer.firstElementChild))

console.log(cardsContainer.firstElementChild.nextElementSibling.classList.toggle('cacher'))

document.querySelector('.regenerer').addEventListener('click', function(e){
    e.preventDefault
    if (cardsContainer.firstElementChild.nextElementSibling.classList.toggle('cacher')) {
        document.querySelector('.regenerer').textContent = 'Faire reapparaitre la carte 2'
    }else{
        document.querySelector('.regenerer').textContent ='Faire disparaitre la carte 2'
    }
})


    document.querySelectorAll('.pcard .pcard__suppression').forEach(element => {
    element.addEventListener('click', function (e) {
        e.preventDefault
        this.closest('article').classList.toggle('cacher')
    })
});




document.querySelector('.regenerer2').addEventListener('click', function(e){
    document.querySelectorAll('.pcard').forEach(element => {
        element.classList.remove('cacher')
    })
})


        document.querySelectorAll('.pcard').forEach(element => {
        element.addEventListener('click', function(e) {
            e.preventDefault()
            this.classList.toggle('pcard--reduit')
        })
    })


//dynamiquement ajouter snas passer par des fonctions

function addCard(e){
    e.preventDefault()
    const firstCard = cardsContainer.firstElementChild
    cloneFirstElement = firstCard.cloneNode(true)
    cloneFirstElement.classList.add('pcard--reduit')
    cloneFirstElement.classList.remove('cacher')
    cloneFirstElement.querySelector('.pcard__suppression').addEventListener('click', function(e){
        this.closest('article').classList.toggle('cacher')
    })
    cloneFirstElement.addEventListener('click', function(e){
        this.classList.toggle('pcard--reduit')
    })
    cardsContainer.appendChild(cloneFirstElement)
    
    console.log(cardsContainer)
}

document.querySelector('.addCard').addEventListener('click', function(e){
   addCard(e)
})

let inter = 0
document.querySelector('.addTimer').addEventListener('click', function (e){
    inter = setInterval(function(){
        addCard(e)
    }, 1000)
})

document.querySelector('.stopTimer').addEventListener('click', function(e){
    e.preventDefault
    setTimeout(function(){
        clearInterval(inter)
    }, 1000)
})

const pElement = document.createElement('p')
pElement.textContent = 'Remplissez le formulaire'
console.log(document.querySelector('aside').childNodes[1].nextElementSibling.appendChild(pElement))

function createForm(objects){
    const form = document.createElement('form')
    form.setAttribute('method', 'POST')
    let nameLabel = 0
    let nameInput = 0
    objects.forEach(element => {
            for (let cle in element) {
                //console.log(`Valeur: ${element['label']}`);

                nameLabel = document.createElement('label');
                nameLabel.textContent = `${element['label']}`;
                nameLabel.setAttribute('for', `${element['attr']}`);

                nameInput = document.createElement('input');
                nameInput.type = `${element['type']}`;
                nameInput.name = `${element['name']}`;
                nameInput.id = `${element['id']}`;
            }
            form.appendChild(nameLabel)
            form.appendChild(nameInput)

    });
    const submitButton = document.createElement('button');
    submitButton.type = 'submit';
    submitButton.textContent = 'Soumettre';

    form.appendChild(submitButton)

    return form
}

let champs = [
    {label: 'Nom: ', attr:'nom', type: 'text', name: 'nom', id:'nom'},
    {label: 'Métier: ', attr:'metier', type: 'text', name: 'metier', id:'metier'},
    {label: 'Pourcentage de satisfaction: ', attr:'satisfaction', type: 'text', name: 'satisfaction', id:'satisfaction'},
    {label: 'Pourcentage occupation: ', attr:'occupation', type: 'text', name: 'occupation', id:'occupation'},
    {label: 'Image: ', attr:'photo', type: 'text', name: 'photo', id:'photo'},
]

formulaire = createForm(champs)
document.querySelector('aside').appendChild(formulaire)

document.querySelector('form').addEventListener('submit', function(e){
    e.preventDefault()
    const formData = new FormData(this);
    /*formData.forEach((value, key) => {
         console.log(key, value);
     });*/
    console.log(formData.get('nom'))
    const firstCard = cardsContainer.firstElementChild
    cloneFirstElement = firstCard.cloneNode(true)
    cloneFirstElement.classList.add('pcard--reduit')
    cloneFirstElement.classList.remove('cacher')
    cloneFirstElement.querySelector('h2.pcard__nom').textContent = formData.get('nom')
    cloneFirstElement.querySelector('h3.pcard__fonction').textContent = formData.get('metier')
    cloneFirstElement.querySelector('.pcard__footer').childNodes[1].querySelector('.pcard__score').textContent = formData.get('satisfaction')
    cloneFirstElement.querySelector('.pcard__footer').lastElementChild.querySelector('.pcard__score').textContent = formData.get('occupation')

    if (formData.get('photo') && formData.get('photo').match(/\.jpg$/i)) {
        cloneFirstElement.querySelector('.pcard__portrait').src = `assets/img/${formData.get('photo')}`

         cloneFirstElement.querySelector('.pcard__suppression').addEventListener('click', function(e){
        this.closest('article').classList.toggle('cacher')
        })
        cloneFirstElement.addEventListener('click', function(e){
            this.classList.toggle('pcard--reduit')
        })
        cardsContainer.appendChild(cloneFirstElement)
    }else{
        const div = document.createElement('div')
        div.textContent = 'format de la photo incorrect !'
        div.style.backgroundColor = 'red'
        document.querySelector('form').appendChild(div)
    }


   
    
    //console.log(cardsContainer)


})
