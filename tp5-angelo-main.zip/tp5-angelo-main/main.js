const jsonObject = {
    "nom":"Guillaume",
    "adresse": {"cp":17000, "ville":"La Rochelle"},
    "notes": [1, 2, 4, 8, 16, 32]
}

const jsonConverted = JSON.stringify(jsonObject)
console.log(jsonConverted)

console.log(jsonObject.nom)
console.log(jsonObject.adresse.ville)
console.log(jsonObject.notes[2])

function getSportifs(){
    fetch('http://localhost:3000/sportifs/') //return ici ?
    .then((response) => response.json()) // formate la reponse en json
    .then((jsonres) => {
            let li = 0
            const ul = document.querySelector('#sportifs')
            jsonres.forEach(sportif => {
                
                li = document.createElement('li')
                li.textContent = sportif.name
                li.setAttribute('data-sportif', sportif.sportId)

                li.addEventListener('click', function(e){
                    const idSpo = this.getAttribute('data-sportif')
                    const url = `http://localhost:3000/sports/?id=${idSpo}`

                    const p = document.createElement('p')
                            fetch(url)
                            .then((response) => response.json())
                            .then((sport) => {
                                console.log(sport[0].name)

                                p.textContent = sport[0].name
                                this.after(p)
                            })
                            .catch((e) => console.log(e))
                })
                ul.appendChild(li)
       });
        //console.log(jsonres);
    })
    .catch((error) => console.log(error))
}

getSportifs() 


//exo 3

function getSportifsAsAw(){
    const asy = async () =>{
        try {
            const response = await fetch('http://localhost:3000/sportifs/')
            const data = await response.json()
            const uli = document.querySelector('#sportifs')
            let li = 0
            data.forEach(sportif => {
                li = document.createElement('li')
                li.textContent = sportif.name
                li.setAttribute('data-sportif', sportif.sportId)

                li.addEventListener('click', function(e){
                    const urlFetch = `http://localhost:3000/sports/?id=${this.getAttribute('data-sportif')}`
                    const pa = document.createElement('p')
                    const asysport = async () =>{
                        try {
                            const res = await fetch(urlFetch)
                            const spodata = await res.json()

                            pa.textContent = spodata[0].name
                            this.after(pa)
                            console.log(spodata)
                            //ici creer le p et le peupler etc...
                        } catch (error) {
                            console.log(error)
                        }
                    }
                    asysport()
                })

                uli.appendChild(li)
            })
            
        } catch (error) {
            console.log(error)
        }
    }
    asy()
}
getSportifsAsAw()

// exo 4

function getWeather(latit, long){
    let lat = latit
    let lon = long
    fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=d7dd8a354a5693ddacd7fca0821bcf6e`)
    .then((response) => response.json())
    .then((json)=>{

        const body = document.querySelector('body')
        const h2 = document.createElement('h2')
        h2.textContent = `Temperature à La Rochelle: ${Number(json.main.temp - 273.15).toFixed(1)} °C`
        body.appendChild(h2)
        const table = document.createElement('table')

        let tr = document.createElement('tr')
        let th = document.createElement('th')
        th.textContent = 'Vent: '
        let td = document.createElement('td')
        td.textContent = `${json.wind.speed} m/s`

        tr.appendChild(th)
        tr.appendChild(td)

        table.appendChild(tr)

        tr = document.createElement('tr')
        th = document.createElement('th')
        th.textContent = 'Nuages: '
        td = document.createElement('td')
        td.textContent = `${json.weather[0].description}`

        tr.appendChild(th)
        tr.appendChild(td)

        table.appendChild(tr)

        tr = document.createElement('tr')
        th = document.createElement('th')
        th.textContent = 'Pression atmospherique: '
        td = document.createElement('td')
        td.textContent = `${json.main.pressure} hpa`

        tr.appendChild(th)
        tr.appendChild(td)

        table.appendChild(tr)

        tr = document.createElement('tr')
        th = document.createElement('th')
        th.textContent = 'Humidité: '
        td = document.createElement('td')
        td.textContent = `${json.main.humidity} %`

        tr.appendChild(th)
        tr.appendChild(td)

        table.appendChild(tr)

        tr = document.createElement('tr')
        th = document.createElement('th')
        th.textContent = 'Levée du soleil: '
        td = document.createElement('td')
        td.textContent = `${new Date(json.sys.sunrise * 1000).getHours()} :  ${new Date(json.sys.sunrise * 1000).getMinutes()}`

        tr.appendChild(th)
        tr.appendChild(td)

        table.appendChild(tr)

        tr = document.createElement('tr')
        th = document.createElement('th')
        th.textContent = 'Couché du soleil: '
        td = document.createElement('td')
        td.textContent = `${new Date(json.sys.sunset * 1000).getHours()} :  ${new Date(json.sys.sunset * 1000).getMinutes()}`

        tr.appendChild(th)
        tr.appendChild(td)

        table.appendChild(tr)

        body.appendChild(table)
        console.log(json)
    })
    .catch((error) => console.log(error))
}
getWeather('46.166667', '-1.150000')

function getWeatherFromCity(cty, strcde){
    city = cty
    sc = strcde
    const fetchAPIWeather = async () =>{
        try {
            const resp = await fetch(`http://api.openweathermap.org/geo/1.0/direct?q=${city},${sc}&limit=1&appid=d7dd8a354a5693ddacd7fca0821bcf6e`)
            const dt = await resp.json()

            console.log(dt[0].lat, dt[0].lon)

            getWeather(dt[0].lat, dt[0].lon)

        } catch (error) {
            console.log(error)
        } 
    }
    fetchAPIWeather()
}
getWeatherFromCity('La Rochelle', '17000')

function getDefibrilators(){
    fetch('https://data.toulouse-metropole.fr/api/explore/v2.1/catalog/datasets/defibrillateurs/records?limit=20')
    .then((response) => response.json())
    .then((json) => {
        
        const map = L.map('map').setView([43.600000, 1.433333], 13);

        L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        }).addTo(map);

        json.results.forEach(obj=>{
            //console.log(obj.geo_point_2d.lat)
            //console.log('rrr')
            marker = L.marker([obj.geo_point_2d.lat, obj.geo_point_2d.lon])
            marker.bindPopup(obj.adresse)
            marker.addTo(map)
        })
    })
    .catch((error) => console.log(error))
    
}
getDefibrilators()

