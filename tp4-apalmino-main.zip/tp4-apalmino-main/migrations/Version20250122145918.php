<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20250122145918 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE contrat (id INT AUTO_INCREMENT NOT NULL, participe_id INT DEFAULT NULL, date_contrat DATE NOT NULL, cachet INT NOT NULL, INDEX IDX_60349993A71D81B9 (participe_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE evenement (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, lieu VARCHAR(255) NOT NULL, nombre_spectateur INT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE groupe (id INT AUTO_INCREMENT NOT NULL, label_id INT DEFAULT NULL, nom VARCHAR(255) NOT NULL, date_creation DATE NOT NULL, date_fin DATE NOT NULL, INDEX IDX_4B98C2133B92F39 (label_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE label (id INT AUTO_INCREMENT NOT NULL, nom VARCHAR(255) NOT NULL, type_production VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE membre (id INT AUTO_INCREMENT NOT NULL, groupe_id INT DEFAULT NULL, musicien_id INT DEFAULT NULL, date_debut_participation DATE NOT NULL, date_fin_participation DATE DEFAULT NULL, INDEX IDX_F6B4FB297A45358C (groupe_id), INDEX IDX_F6B4FB2960A30C4A (musicien_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE musicien (id INT AUTO_INCREMENT NOT NULL, prenom VARCHAR(255) NOT NULL, nom VARCHAR(255) NOT NULL, date_naissance DATE NOT NULL, date_deces DATE DEFAULT NULL, instrument LONGTEXT NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('CREATE TABLE participe (id INT AUTO_INCREMENT NOT NULL, evenement_id INT DEFAULT NULL, contrat_id INT DEFAULT NULL, groupe_id INT DEFAULT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL, INDEX IDX_9FFA8D4FD02F13 (evenement_id), INDEX IDX_9FFA8D41823061F (contrat_id), INDEX IDX_9FFA8D47A45358C (groupe_id), PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('ALTER TABLE contrat ADD CONSTRAINT FK_60349993A71D81B9 FOREIGN KEY (participe_id) REFERENCES participe (id)');
        $this->addSql('ALTER TABLE groupe ADD CONSTRAINT FK_4B98C2133B92F39 FOREIGN KEY (label_id) REFERENCES label (id)');
        $this->addSql('ALTER TABLE membre ADD CONSTRAINT FK_F6B4FB297A45358C FOREIGN KEY (groupe_id) REFERENCES groupe (id)');
        $this->addSql('ALTER TABLE membre ADD CONSTRAINT FK_F6B4FB2960A30C4A FOREIGN KEY (musicien_id) REFERENCES musicien (id)');
        $this->addSql('ALTER TABLE participe ADD CONSTRAINT FK_9FFA8D4FD02F13 FOREIGN KEY (evenement_id) REFERENCES evenement (id)');
        $this->addSql('ALTER TABLE participe ADD CONSTRAINT FK_9FFA8D41823061F FOREIGN KEY (contrat_id) REFERENCES contrat (id)');
        $this->addSql('ALTER TABLE participe ADD CONSTRAINT FK_9FFA8D47A45358C FOREIGN KEY (groupe_id) REFERENCES groupe (id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE contrat DROP FOREIGN KEY FK_60349993A71D81B9');
        $this->addSql('ALTER TABLE groupe DROP FOREIGN KEY FK_4B98C2133B92F39');
        $this->addSql('ALTER TABLE membre DROP FOREIGN KEY FK_F6B4FB297A45358C');
        $this->addSql('ALTER TABLE membre DROP FOREIGN KEY FK_F6B4FB2960A30C4A');
        $this->addSql('ALTER TABLE participe DROP FOREIGN KEY FK_9FFA8D4FD02F13');
        $this->addSql('ALTER TABLE participe DROP FOREIGN KEY FK_9FFA8D41823061F');
        $this->addSql('ALTER TABLE participe DROP FOREIGN KEY FK_9FFA8D47A45358C');
        $this->addSql('DROP TABLE contrat');
        $this->addSql('DROP TABLE evenement');
        $this->addSql('DROP TABLE groupe');
        $this->addSql('DROP TABLE label');
        $this->addSql('DROP TABLE membre');
        $this->addSql('DROP TABLE musicien');
        $this->addSql('DROP TABLE participe');
    }
}
