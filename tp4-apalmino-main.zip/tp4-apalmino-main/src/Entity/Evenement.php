<?php

namespace App\Entity;

use ApiPlatform\Metadata\ApiResource;
use App\Repository\EvenementRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EvenementRepository::class)]
#[ApiResource]
class Evenement
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $nom = null;

    #[ORM\Column(length: 255)]
    private ?string $lieu = null;

    #[ORM\Column]
    private ?int $nombreSpectateur = null;

    /**
     * @var Collection<int, Participe>
     */
    #[ORM\OneToMany(targetEntity: Participe::class, mappedBy: 'evenement')]
    private Collection $participent;

    public function __construct()
    {
        $this->participent = new ArrayCollection();
    }



    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): static
    {
        $this->nom = $nom;

        return $this;
    }

    public function getLieu(): ?string
    {
        return $this->lieu;
    }

    public function setLieu(string $lieu): static
    {
        $this->lieu = $lieu;

        return $this;
    }

    public function getNombreSpectateur(): ?int
    {
        return $this->nombreSpectateur;
    }

    public function setNombreSpectateur(int $nombreSpectateur): static
    {
        $this->nombreSpectateur = $nombreSpectateur;

        return $this;
    }

    /**
     * @return Collection<int, Participe>
     */
    public function getParticipent(): Collection
    {
        return $this->participent;
    }

    public function addParticipent(Participe $participent): static
    {
        if (!$this->participent->contains($participent)) {
            $this->participent->add($participent);
            $participent->setEvenement($this);
        }

        return $this;
    }

    public function removeParticipent(Participe $participent): static
    {
        if ($this->participent->removeElement($participent)) {
            // set the owning side to null (unless already changed)
            if ($participent->getEvenement() === $this) {
                $participent->setEvenement(null);
            }
        }

        return $this;
    }

}
