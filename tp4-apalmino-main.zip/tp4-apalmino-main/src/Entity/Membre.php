<?php

namespace App\Entity;

use App\Repository\MembreRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Metadata\ApiResource;

#[ApiResource]
#[ORM\Entity(repositoryClass: MembreRepository::class)]
class Membre
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $dateDebutParticipation = null;

    #[ORM\Column(type: Types::DATE_MUTABLE, nullable: true)]
    private ?\DateTimeInterface $dateFinParticipation = null;

    #[ORM\ManyToOne(inversedBy: 'membres')]
    private ?Groupe $groupe = null;

    #[ORM\ManyToOne(inversedBy: 'membres')]
    private ?Musicien $musicien = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateDebutParticipation(): ?\DateTimeInterface
    {
        return $this->dateDebutParticipation;
    }

    public function setDateDebutParticipation(\DateTimeInterface $dateDebutParticipation): static
    {
        $this->dateDebutParticipation = $dateDebutParticipation;

        return $this;
    }

    public function getDateFinParticipation(): ?\DateTimeInterface
    {
        return $this->dateFinParticipation;
    }

    public function setDateFinParticipation(?\DateTimeInterface $dateFinParticipation): static
    {
        $this->dateFinParticipation = $dateFinParticipation;

        return $this;
    }

    public function getGroupe(): ?Groupe
    {
        return $this->groupe;
    }

    public function setGroupe(?Groupe $groupe): static
    {
        $this->groupe = $groupe;

        return $this;
    }

    public function getMusicien(): ?Musicien
    {
        return $this->musicien;
    }

    public function setMusicien(?Musicien $musicien): static
    {
        $this->musicien = $musicien;

        return $this;
    }
}
