# TP2 Symfony

## Objectifs

- Mise en place d’un workflow avec Docker.
- Créer un site avec le framework symfony 7 en créant des entités.
- Être béta testeur d'une application créé par l'enseignant ;)

## Préparation du poste de travail

Vous utiliserez votre machine personnelle en réutilisant la stack docker utilisé lors du premier TP.

## Utilisation de gitlabclassroom

Connectez-vous au gitlab de l'univeristé puis acceptez l'invitation pour rejoindre la [classe symfony](https://lpmiaw.univ-lr.fr/gitlabclassroom/classroom/0192f287-4843-7771-9b1d-9c3f69c5e86c/join)

Acceptez maintenant l'invitation pour le [tp de cette semaine](https://lpmiaw.univ-lr.fr/gitlabclassroom/assignment/0192f294-f0c3-70ec-b3ea-47aac0a599e7/accept).

En allant sur le [lien de la classe](https://gitlab.univ-lr.fr/lpmiaw-2024-2025/Symfony/TP2), vous devez voir votre projet sur lequel vous allez travailler.

## Réalisation

### ETQ gestionnaire, je veux un environnement commun à tous les développeurs

> Création du projet

```bash
# dossier devPhpLp (WSL pour windows)
# pas de majuscule pour le nom des projets
make newSF sftp2
```

Cela va créer un nouveau projet symfony 7 dans le dossier sftp2 ainsi qu'une base de données associée.

Nous voulons remplacer le contenu de ce nouveau projet vierge par celui de gitlab.

```bash
# toujours dans le dossier devPhpLp
# on sauvegarde le fichier de connnexion à la base de données
cp projets/sftp2/.env.local .env.local.sftp2
# on supprime le dossier sftp2
rm -rf projets/sftp2
# on clone le projet gitlab avec le même nom que le dossier supprimé
git clone git@gitlab.univ-lr.fr:lpmiaw-2024-2025/Symfony/TP2/tp2-{votre_login}.git projets/sftp2
# on remet le fichier de connexion à la base de données
mv .env.local.sftp2 projets/sftp2/.env.local
# on installe les dépendances au projet
make bash
cd sftp2
composer install
```

Fermer le terminal et lancez phpStorm pour ouvrir le dossier sftp2.

Installez les plugins .env et symfony (si vous ne l’avez pas déjà fait)

Ouvrez un terminal dans phpStorm pour travailler.

> Tests et validation

Normalement, si vous allez sur [https://sftp2.localhost:8443](https://sftp2.localhost:8443), vous devez voir la page 404 de symfony.

Vérifiez que le fichier .env.local généré par le Makefile est bien présent dans votre projet.

### ETQ gestionnaire, je veux un découpage fonctionnel du site

Le site commandé est déjà réalisé par l’équipe WDI et est disponible dans le dossier siteStatique au format html5/css.

> Installation des composants nécessaires

Ajoutez les mêmes composants qu’au TP1 à l’aide de la commande composer

```bash
# dans le dossier devPhpLp
make bash
# on se place dans le dossier de son projet
cd sftp2
# on installe les dépendances nécessaires
composer req ...
# création d’un contrôleur pour notre application
bin/console make:controller
```

Choisissez le nom Default.

Changez le chemin de la route en / et le nom de la route en app_homepage

> Utilisation des ressources

Copiez les dossiers images, css et js dans public/

> Découpage de la maquette html/css

Analyser le code html afin de trouver les parties communes à insérer dans base.html.twig puis la partie spécifique dans default/index.html.twig.

> Tests et validation

Actualisez votre navigateur et votre site doit être graphiquement fonctionnel.

Modifiez l’attribut de routage de votre contrôleur en /test/validation et faites en sorte que cela fonctionne à nouveau en utilisant le principe des assets.

### ETQ gestionnaire, je veux pouvoir gérer des spectacles

> Création de l’entité spectacle

En utilisant la bonne commande symfony, créez une entité "Spectacle" :

- nom : string
- description : text
- image : string
- date : date

> Ajout des méthodes nécessaires dans la classe

Ajoutez un constructeur à la classe Spectacle (Dans Phpstorm : Alt+Inser) ainsi que la méthode __toString()

> Tests et validation

Dans le contrôleur, dans une nouvelle méthode, créez un nouvel spectacle.

En cliquant sur le lien test, il faut aller vers la page /spectacle/test qui affiche le spectacle créé.

Pour l’instant, le spectacle n’est pas issu de la base de données, il est uniquement en mémoire.

> Création effective de la table

En utilisant la bonne commande symfony, faites l’association entre l’entité et la table au niveau de la base.

> Ajout de données.

Nous allons utiliser l’outil Database de PhpStorm à la place de phpmyadmin. 
Vous trouverez également adminer à l’adresse [http://localhost:8306](http://localhost:8306) pour ceux qui préfèrent. 
Ouvrez l’onglet et ajoutez une connexion mariadb. Télécharger les drivers manquants en cliquant en bas de la fenêtre puis entrez les informations suivantes :

- User : root
- Password : root
- Database : sftp2

Cliquez sur Test connection puis si c’est bon, cliquez sur OK.

Ajoutez des spectacles en ouvrant la table spectacle sur dans l'onglet Database (les images seront enregistrées dans le dossier images adéquat en dur)

Dans le champ image, nous écrirons uniquement le chemin de l’image

> Tests et validation

En cliquant sur le lien Spectacles, il faut aller vers la page /spectacles qui affiche tous les spectacles enregistrés sous forme d’un tableau html.

### ETQ gestionnaire, je veux pouvoir associer aux spectacles les lieux où ils sont situés

> Création de l’entité Lieu

- nom : string
- adresse : string
- codePostal : string(5)
- ville : string

> Ajout des méthodes nécessaires dans la classe

Ajoutez un constructeur à la classe Lieu (Dans Phpstorm : Alt+Inser) ainsi que la méthode __toString()

> Ajout de données dans la table

Ajoutez des lieux dans la table. (pensez à rafraîchir la vue database de phpStorm)

> Tests et validation

En cliquant sur le lien Lieux, il faut aller vers la page /lieux qui affiche tous les lieux enregistrés

> Modification de l’entité Spectacle

Ajoutez un champ lieu à la classe Spectacle en utilisant une commande symfony

En type, vous pouvez utiliser relation

Liaison entre Spectacle et Lieu : un spectacle appartient à un lieu (many-to-one)

Visualiser la table spectacle grâce à l’outil database de Phpstorm pour voir les changements opérés.

> Tests et validation

Ajoutez un lieu existant à chaque spectacle

En cliquant sur le lien Spectacles, affichez maintenant les spectacles avec le nom du lieu associé.

### ETQ gestionnaire, je veux pouvoir ajouter des spectacles

> Création d’un formulaire d’ajout

```bash
bin/console make:form
```

Il faut associer le formulaire à l’entité

> Création de la vue associée

Créez le fichier twig permettant d’afficher le formulaire.

> Ajout de la méthode du contrôleur

Dans une nouvelle méthode correspondant à la route /spectacle/ajout, gérer le traitement du formulaire ainsi que l’insertion dans la base de données.

> Tests et validation

En cliquant sur le lien + Spectacle, il faut aller vers la page /spectacle/ajout qui affiche un formulaire permettant d’ajouter un spectacle en choisissant son lieu

Vous devrez modifier légèrement le constructeur de la classe Spectacle

> Bonus:

- un code postal ne doit contenir uniquement des chiffres
- la date doit pouvoir être choisie à travers un calendrier html5 plutôt que les selects par défaut.

### ETQ gestionnaire, je veux pouvoir facilement lister, supprimer, éditer un lieu

> Création du crud

```bash
bin/console make:crud
```

> Tests et validation

En cliquant sur le lien Crud, il faut aller vers la page /lieu qui affiche la liste des lieux qui auront un lien pour ajouter/éditer un lieu en français.

Observez attentivement l’ensemble du code généré : Controller, Formulaire, Vue…

### ETQ chef de projet, je veux un jeu de données pour l’application

> Gestion avec git

Sur gitlab, créez une nouvelle issue gérer cette tâche à effectuer.

Sur votre poste, actualisez git et placez-vous sur la nouvelle branche.

> Création des [fixtures](https://symfony.com/bundles/DoctrineFixturesBundle/current/index.html)

Effectuez les manipulations afin de créer la classe permettant la création du jeu de données.

Nous voulons 20 lieux, et 20 spectacles associés à un lieu tiré au sort.

> Tests et validation

En cliquant sur le lien spectacles, il faut aller vers la page /spectacles qui affiche tous les spectacles enregistrés sous forme d’un tableau html. 
Le lien lieux permet de visualiser tous les lieux.

Une fois les tests validés, résolvez l’issue et réalisez la merge request associée.

### ETQ gestionnaire, je veux ajouter des participants aux spectacles

> Gestion avec git

Sur gitlab, créez une nouvelle issue et une merge request pour gérer cette tâche à effectuer.

Sur votre poste, actualisez git et placez-vous sur la nouvelle branche.

> Création de l’entité

Un participant possède un nom, un prénom et une adresse email. Il peut assister à plusieurs spectacles et un spectacle peut accueillir plusieurs participants.
La relation devra être créée en modifiant Spectacle pour lui ajouter des participants.

> Modification des fixtures

Modifiez la classe des fixtures pour ajouter au moins deux participants à chaque spectacle.

> Tests et validation

En allant sur un spectacle particulier, on doit pouvoir avoir les informations d’un spectacle avec la liste des participants.
Une fois les tests validés, résolvez l’issue et réaliser la merge request associée.

### ETQ utilisateur, je veux pouvoir m’inscrire en tant que participant en sélectionnant un ou plusieurs spectacles.

> Ajout des méthodes de contrôleur et des vues

Réalisez cette tâche en reprenant la méthodologie de git vue précédemment. 

Je ne vous guide pas pour réaliser cette US. Réfléchissez à la meilleure solution possible.

> Test et validation (pas facile car mal documenté)

Il faudra s’assurer que le nouveau participant apparaisse bien dans les spectacles où il s’est inscrit.

[https://symfony.com/doc/current/form/form_collections.html#handling-the-new-tags-in-php](https://symfony.com/doc/current/form/form_collections.html#handling-the-new-tags-in-php)
[https://symfony.com/doc/current/reference/forms/types/collection.html#by-reference](https://symfony.com/doc/current/reference/forms/types/collection.html#by-reference)