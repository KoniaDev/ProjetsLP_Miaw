<?php

namespace App\Tests;

use App\Repository\SpectacleRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;
use App\Entity\Spectacle;
use App\Entity\Lieu;

class Tp2Test extends WebTestCase
{
    public function testAppHomepage(): void
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h1', 'TP2');
        $this->assertSelectorTextContains('footer p', 'Année Universitaire');
        $this->assertCount(3, $crawler->filter('script'));
        $this->assertCount(3, $crawler->filter('link'));
    }

    public function testNewSpectacle()
    {
        $client = static::createClient();
        $spectacle = new Spectacle("mon spectacle");
        $this->assertEquals("mon spectacle", $spectacle->getNom());
        $crawler = $client->request('GET', '/spectacle/test');
        $this->assertResponseIsSuccessful();
        $this->assertCount(1, $crawler->filter("main h2"));
    }

    public function testSpectacles()
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/spectacles');
        $this->assertResponseIsSuccessful();
        $this->assertCount(1, $crawler->filter('main h2'));
        $this->assertSelectorTextContains('main h2', 'Liste des spectacles');
    }

    public function testLieu() {
        $client = static::createClient();
        $lieu = new Lieu("mon lieu");
        $this->assertEquals("mon lieu", $lieu);
        $spectacle = new Spectacle("mon spectacle");
        $spectacle->setLieu($lieu);
        $this->assertEquals("mon lieu", $spectacle->getLieu());
        $crawler = $client->request('GET', '/lieux');
        $this->assertResponseIsSuccessful();
        $this->assertCount(1, $crawler->filter('main h2'));
        $this->assertSelectorTextContains('main h2', 'Liste des lieux');
    }

    public function testAddSpectacle() {
        $client = static::createClient();
        $crawler = $client->request('GET', '/spectacle/ajout');
        $this->assertResponseIsSuccessful();
        $this->assertCount(1, $crawler->filter('form'));
        $client->submitForm('submit', [
            'spectacle[nom]' => 'Late Show',
            'spectacle[description]' => 'Some feedback from an automated functional test',
            'spectacle[image]' => 'images/5.jpg',
            'spectacle[lieu]' => 2,
        ]);
        $this->assertResponseRedirects();
        // simulate Spectacle validation
        $spectacle = self::getContainer()->get(SpectacleRepository::class)->findOneByNom('Late Show');
        $spectacle->setDate(new \DateTime());
        self::getContainer()->get(EntityManagerInterface::class)->flush();
        $client->followRedirect();
        $this->assertSelectorExists('h2:contains("Liste des spectacles")');
    }

    public function testEditSpectacle()
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/spectacle/spectacle10/edit');
        $this->assertResponseIsSuccessful();
        $this->assertCount(1, $crawler->filter('form'));
        $client->submitForm('submit', [
            'spectacle[nom]' => 'Late Show',
            'spectacle[description]' => 'Some feedback from an automated functional test',
            'spectacle[image]' => 'images/5.jpg',
            'spectacle[lieu]' => 2,
        ]);
        $this->assertResponseRedirects();
        $client->followRedirect();
        $this->assertSelectorExists('h2:contains("Liste des spectacles")');
    }

    public function testInscription()
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/inscription');
        $this->assertResponseIsSuccessful();
        $this->assertCount(1, $crawler->filter('form'));
        $client->submitForm('submit', [
            'participant[nom]' => 'test',
            'participant[prenom]' => 'test',
            'participant[email]' => 'gg@gg.fr'
            ]);
    }



}
