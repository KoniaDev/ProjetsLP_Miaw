import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import TemperatureDisplay from "./TemperatureDisplay.jsx";
import WeatherCode from "./WeatherCode.jsx";
import ForecastItem from "./ForecastItem.jsx";

const apiEndpoint = "https://api.open-meteo.com/v1/forecast";
const userTimezone = "Europe/London";
const dailyParams = ["weathercode", "temperature_2m_max", "temperature_2m_min"];
const hourlyParams = ["temperature_2m", "weathercode"];

const WeatherWidget = ({ cityName, latitude, longitude }) => {
  const [weatherData, setWeatherData] = useState({ data: null });
  const [lastUpdate, setLastUpdate] = useState(null);
  const [activeTab, setActiveTab] = useState("day");

  const fetchWeather = async () => {
    try {
      console.log("Retrieving weather information...");
      const response = await fetch(
        `${apiEndpoint}?latitude=${latitude}&longitude=${longitude}&hourly=${hourlyParams.join(",")}&daily=${dailyParams.join(",")}&timezone=${userTimezone}`
      );

      if (!response.ok) {
        throw new Error("Failed to fetch data");
      }

      const result = await response.json();
      console.log("Data retrieved:", result);
      setWeatherData({ data: result });
      setLastUpdate(Date.now());
    } catch (err) {
      console.error("Error during fetch:", err);
    }
  };

  useEffect(() => {
    fetchWeather();
    const refreshInterval = setInterval(fetchWeather, 10000);
    return () => clearInterval(refreshInterval);
  }, [latitude, longitude]);

  const formatTimestamp = (timestamp) => {
    if (!timestamp) return "";
    const dateObj = new Date(timestamp);
    return dateObj.toLocaleTimeString("fr-FR", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const currentDate = new Date().toLocaleDateString("fr-FR");

  return (
    <div className="weather-widget">
      <div className="weather-container-content">
        <header className="weather-container-header">
          <p className="location">{cityName}</p>
          <button className="refresh-button" onClick={fetchWeather}>
            <img
              src="https://lpmiaw-react.napkid.dev/img/weather/refresh.png"
              alt="Refresh"
            />
          </button>
        </header>
        <p className="date">{currentDate}</p>
        {weatherData.data ? (
          <article className="today">
            <WeatherCode code={weatherData.data.daily.weathercode[0]} />
            <TemperatureDisplay
              min={Math.floor(weatherData.data.daily.temperature_2m_min[0])}
              max={Math.floor(weatherData.data.daily.temperature_2m_max[0])}
              avg={Math.floor(
                (weatherData.data.daily.temperature_2m_max[0] +
                  weatherData.data.daily.temperature_2m_min[0]) /
                  2
              )}
            />
          </article>
        ) : (
          <p>No data available</p>
        )}

        <section>
          <nav className="tabs">
            <button
              onClick={() => setActiveTab("day")}
              className={activeTab === "day" ? "tab tab--active" : "tab"}
            >
              Day
            </button>
            <button
              onClick={() => setActiveTab("week")}
              className={activeTab === "week" ? "tab tab--active" : "tab"}
            >
              Week
            </button>
          </nav>

          <ul className="forecast">
            {weatherData.data &&
              activeTab === "week" &&
              Array(5)
                .fill(null)
                .map((_, index) => (
                  <ForecastItem
                    key={index}
                    code={weatherData.data.daily.weathercode[index + 1]}
                    label={new Date(weatherData.data.daily.time[index + 1])
                      .toLocaleDateString("fr-FR")
                      .slice(0, -5)}
                    temperature={parseFloat(
                      (
                        (weatherData.data.daily.temperature_2m_max[index + 1] +
                          weatherData.data.daily.temperature_2m_min[index + 1]) /
                        2
                      ).toFixed(1)
                    )}
                  />
                ))}

            {weatherData.data &&
              activeTab === "day" &&
              Array(5)
                .fill(null)
                .map((_, index) => (
                  <ForecastItem
                    key={index}
                    code={weatherData.data.hourly.weathercode[6 + index * 4]}
                    label={`${6 + index * 4}h`}
                    temperature={
                      weatherData.data.hourly.temperature_2m[6 + index * 4]
                    }
                  />
                ))}

            {!weatherData.data &&
              Array(5)
                .fill(null)
                .map((_, index) => (
                  <ForecastItem
                    key={index}
                    label="10h"
                    code={55}
                    temperature={21}
                  />
                ))}
          </ul>
        </section>

        <footer className="weather-container-footer">
          <p>Last updated at {lastUpdate ? formatTimestamp(lastUpdate) : "..."}</p>
        </footer>
      </div>
    </div>
  );
};

WeatherWidget.propTypes = {
  cityName: PropTypes.string.isRequired,
  latitude: PropTypes.number.isRequired,
  longitude: PropTypes.number.isRequired,
};

export default WeatherWidget;
