import React from 'react'
import WeatherCode from './WeatherCode'
import PropTypes from 'prop-types'



const ForecastItem = (props) => {
    return (
        <li className="forecast-item">
            <p>
            {props.label}
            </p>
            <WeatherCode code={props.code}/>
            <p className="forecast-item-temp">
              {props.temperature}
            </p>
        </li>
    )

   
}
 ForecastItem.propTypes = {
        code: PropTypes.number.isRequired,
        label: PropTypes.string.isRequired,
        temperature: PropTypes.number.isRequired
    }
export default ForecastItem