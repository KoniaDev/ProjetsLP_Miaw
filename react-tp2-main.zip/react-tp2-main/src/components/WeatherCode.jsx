import React from 'react'
import PropTypes from 'prop-types'


import cloudsIcon from '../assets/img/clouds.png'
import fogIcon from '../assets/img/fog.png'
import heavyRainIcon from '../assets/img/heavy-rain.png'
import heavySnowIcon from '../assets/img/heavy-snow.png'
import partialSunIcon from '../assets/img/partial-sun.png'
import slightSnowIcon from '../assets/img/slight-snow.png'
import sunRainIcon from '../assets/img/sun-rain.png'
import sunshineIcon from '../assets/img/sunshine.png'
import thunderstormIcon from '../assets/img/thunderstorm.png'

const WeatherCode = (props) =>{
    const codes = {
        0: sunshineIcon,
        2: partialSunIcon,
        3: cloudsIcon,
        45: fogIcon,
        51: sunRainIcon,
        65: heavyRainIcon,
        71: slightSnowIcon,
        75: heavySnowIcon,
        80: heavyRainIcon,
        85: heavySnowIcon,
        95: thunderstormIcon,
    }

    const sortedKeys = Object.keys(codes)
        .sort((a, b) => a - b);

    let closestKey = null;

    for (const key of sortedKeys) {
        if (key === props.code) {
            closestKey = codes[key];
            break
        } else if (key < props.code) {
            closestKey = key; 
        } else {
            break; 
        }
    }
    
    let pictureUrl =  closestKey !== null ? codes[closestKey] : null;
    return(
        <img
        src={pictureUrl}
        className="weathercode-img"
        alt="Logo"
    />
    )
}

WeatherCode.propTypes = {
    code: PropTypes.number.isRequired
}


export default WeatherCode