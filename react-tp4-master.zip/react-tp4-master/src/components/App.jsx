import React, {useEffect} from 'react'
import {BrowserRouter, Routes, Route, Redirect} from 'react-router-dom'
import Home from '../pages/Home'
import Gallery from '../pages/Gallery'
import Login from '../pages/Login'
import Logout from '../pages/Logout'
import Upload from '../pages/Upload'
import Layout from './Layout'
import Navbar from './Navbar'
import { useReducer } from "react";
import { createContext } from 'react'



export const AuthContext = createContext();

const App = () => {
  const [state, dispatch] = useReducer(
    (state, action) => {
      switch (action.type) {
        case "login_start":
          return {
            loading: true,
            error: false,
            user: {
              username: null,
            },
            success: false,
          };
        case "login_success":
          return {
            loading: false,
            error: false,
            user: {
              username: "test@mail.com",
            },
            success: true,
          };
        case "login_error":
          return {
            loading: false,
            error: true,
            user: {
              username: null,
            },
            success: false,
          };
        default:
          return state;
      }
    },
    {
      loading: false,
      error: false,
      user: {
        username: null,
      },
      success: false,
    }
  );

  useEffect(() => {

    fetch("/api/auth/me", {
      method: "GET",
      credentials: "same-origin", 
    })
      .then((res) => {
        if (res.ok) {
          return res.json(); 
        } else {
          throw new Error("Utilisateur non connecté");
        }
      })
      .then((data) => {
        dispatch({ type: "login_success", payload: data });
      })
      .catch((error) => {
        console.error("Erreur lors de la vérification de l'authentification :", error);
        dispatch({ type: "login_error" });
      });
  }, []);



  const login = (cred) => {
    dispatch({ type: "login_start" });
    fetch("/api/auth/login", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username: cred.username,
        password: cred.password,
      }),
    })
      .then((res) => {
        if (!res.ok) {
          dispatch({ type: "login_error" });
          throw new Error("Erreur réseau lors de la requête");
        }
        return res.json();
      })
      .then((data) => {
        console.log(data);
        dispatch({ type: "login_success" });
      })
      .catch((error) => {
        dispatch({ type: "login_error" });
        console.error("Une erreur est survenue :", error);
      });
  };

  return (
    <AuthContext.Provider value={[state, { login }]}>
      <BrowserRouter>
        <Navbar />
        <Routes>
          <Route index={true} element={<Home />} />
          <Route path="/gallery" element={<Gallery />} />
          <Route path="/login" element={<Login />} />
          <Route path="/logout" element={<Logout />} />
          <Route path="/upload" element={<Upload />} />
        </Routes>
      </BrowserRouter>
    </AuthContext.Provider>
  );
};

export default App;