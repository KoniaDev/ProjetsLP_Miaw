import React,{ useContext } from 'react'
import {Navigate} from 'react-router-dom'
import { AuthContext } from "../components/App";

const Logout = () => {
    const [state, { login }] = useContext(AuthContext);
          console.log(state)
          if (state.user.username===null) {
              return (
                  <Navigate 
                      to={{
                          pathname: '/login'
                      }} 
                  />
              );
          }

    const logout = () => {
        fetch("/api/auth/logout", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
           
          })
            .then((res) => {
              if (!res.ok) {
                throw new Error("Erreur réseau lors de la requête");
              }
              return res.json();
            })
            .then((data) => {
              console.log(data);
            })
            .catch((error) => {
              console.error("Une erreur est survenue :", error);
            });
        };
    
    return <div className="container mx-auto px-4 h-full">
        <div className="flex content-center items-center justify-center h-full">
            <div className="w-full lg:w-4/12 px-4 shadow py-24 text-center">
                <p>Revenez vite !</p>
                <button className="mt-6 bg-pink-500 text-white active:bg-pink-600 text-xs font-bold uppercase px-4 py-2 rounded shadow hover:shadow-md outline-none focus:outline-none" onClick={logout()}>
                    Déconnexion
                </button>
            </div>
        </div>
    </div>
}

export default Logout
