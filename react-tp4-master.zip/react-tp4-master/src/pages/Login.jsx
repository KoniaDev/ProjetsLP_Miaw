import React, { useContext } from "react";
import LoginForm from "../components/LoginForm";
import Alert from "../components/Alert";
import { AuthContext } from "../components/App";
import {Navigate} from 'react-router-dom'
const Login = () => {

  const [state, { login }] = useContext(AuthContext);
      console.log(state)
      if (state.user.username) {
          return (
              <Navigate 
                  to={{
                      pathname: '/upload'
                  }} 
              />
          );
      }
  return (
    <div className="container mx-auto px-4 h-full">
      <div className="flex content-center items-center justify-center h-full">
        <div className="w-full lg:w-4/12 px-4">

          {state.success ? (
            <Alert
              status={"success"}
              description="Bravo, vous vous êtes connectés !"
            />
          ) : (
            state.error && (
              <Alert
                status={"error"}
                description="Erreur, mot de passe ou identifiant incorrect !"
              />
            )
          )}


          <LoginForm
            onSubmit={(credentials) => login(credentials)} 
            disabled={state.loading}
          />
        </div>
      </div>
    </div>
  );
};

export default Login;