import React, { useEffect, useState, useContext } from 'react'
import Fab from '../components/Fab'
import Thumbnail from '../components/Thumbnail'
import { Link } from 'react-router-dom'
import { AuthContext } from "../components/App";

const Gallery = () => {

    const [images, setImages] = useState([])
    const [state, { login }] = useContext(AuthContext);
    useEffect(() => {
        fetch('/api/images')
        .then(res => res.json())
        .then(data => setImages(data))
    }, [])
    
    

    /*const images = [{
        id: "1000",
        author: "0",
        url: "https://picsum.photos/id/1000/200/300",
        description: "Sample from Unsplash"
    },
    {
        id: "1001",
        author: "0",
        url: "https://picsum.photos/id/1001/200/300",
        description: "Sample from Unsplash"
    },
    {
        id: "1002",
        author: "0",
        url: "https://picsum.photos/id/1002/200/300",
        description: "Sample from Unsplash"
    }] */

    return <div className="mx-auto">
        <ul className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-1 mx-auto">
                {images.map((img) =>{
                return <li>
                    {console.log(img)}
                    <Thumbnail
                        url={img.url}
                        description={img.description}
                    />
                </li>
                }
            )}
        </ul>
       
        {state.user.username ? (
        <Link to="/upload">
            <Fab icon="+" />
        </Link>
    ) : null}
    </div>
}

export default Gallery