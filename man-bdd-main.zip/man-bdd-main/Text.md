# Domaine d'application

- **Gestion de bibliothèque :**

Ce projet concerne un système de gestion informatisé pour une bibliothèque. Actuellement, le système est conçu pour gérer une seule bibliothèque.

- **Contexte :**

La bibliothèque solidaire "La Bibliothèque pour Tous" souhaite moderniser son fonctionnement en mettant en place un système de gestion des stocks et des prêts de livres. Ce système permettra de faciliter la location en ligne de ses ouvrages, et de générer des statistiques sur ses locations et ouvrages.

- **Objectifs et contraintes :**

Chaque livre peut être disponible en plusieurs exemplaires, et ceux-ci doivent être gérés individuellement.
Le système doit permettre de suivre l'état des prêts (livre en cours de location, rendu, etc.), d'identifier leur genre et auteur.
Une attention particulière est portée sur la gestion des exemplaires, pour assurer un suivi précis des disponibilités.

# Requêtes :

## Angelo

### Liste des exemplaires qui n'ont jamais eu de locations

```
select Exemplaires.idExemplaire, location.id, Exemplaires.isbn
from Exemplaires
left join Location
on location.idExemplaire = Exemplaires.idExemplaire
where Location.id ISNULL

```

### Compte tous les exmplaires des ouvrages

```
select ouvrage.titre, ouvrage.isbn, count (*)
from Ouvrage 
join Exemplaires
on Exemplaires.isbn = ouvrage.isbn
GROUP by Ouvrage.titre

```

### Compte tous les exemplaires en prenant en compte ceux loués

```
select ouvrage.titre, ouvrage.isbn, count (*)
from Ouvrage 
join Exemplaires
on Exemplaires.isbn = ouvrage.isbn
join Location 
on exemplaires.idExemplaire = location.idExemplaire
WHERE Location.rendu = 'oui'
GROUP by Ouvrage.titre

```

### Livres n'ayant jamais eu de location

```

select Ouvrage.titre
from Location
RIGHT JOIN Ouvrage
on ouvrage.isbn = location.isbnExemplaires
where location.isbnExemplaires ISNULL

```

### Trouver les categories qui n'ont pas de livre

```

select Categorie.libelle
FROM Categorie
left join Ouvrage
on ouvrage.idCategorie = Categorie.id
WHERE ouvrage.idCategorie ISNULL

```

### Compter les livres par categories

```

select Categorie.libelle, count (Categorie.id)
FROM Categorie
RIGHT join Ouvrage
on ouvrage.idCategorie = Categorie.id
GROUP by Categorie.id;

```

### Livres les plus loués chez les 30 - 40ans

```

select ouvrage.titre, count(*) as qte
from Ouvrage
join Location
ON ouvrage.isbn = Location.isbnExemplaires
join Client
on Location.idClient = Client.id
where client.age > 30 and client.age < 40
group by Ouvrage.isbn
ORDER BY qte DESC

```

### Top des livres loués par années

```

select ouvrage.titre, strftime('%Y', Location.dateDebut) AS annee, count(*)
from Ouvrage
join Location
ON ouvrage.isbn = Location.isbnExemplaires
group by annee
order by annee DESC

```

### Titres des ouvrages qui ont des exemplaire qui n'ont pas ete rendus

```

SELECT ouvrage.titre
from Ouvrage
	where exists(
    select 1
      from Location
      where location.rendu = 'non'
      AND Location.isbnExemplaires = Ouvrage.isbn
    )


```

### Recuperer les livres qui sont dans la categorie romans

```

SELECT Ouvrage.titre
from Ouvrage
where idcategorie IN(
  select id
  from Categorie
  where categorie.libelle = 'Roman');

```

### Moyenne des ages des personnes lisant de la science fiction

```

select AVG(Client.age)
from Client
join Location
on client.id = location.idClient
join Ouvrage
on ouvrage.isbn = location.isbnExemplaires 
join Categorie
on ouvrage.idCategorie = Categorie.id
where Categorie.libelle = 'Science-fiction'

```

### Liste des clients ayant un emprunt en cours

```

select client.id, client.nom, client.prenom
from Client
WHERE EXISTS(
  select 1
  from Location
  WHERE location.rendu = 'non'
	and location.idClient = Client.id)

```

### Durée de location des livres par clients

```

select Client.id, client.nom, client.prenom, julianday(location.dateFin)-julianday(Location.dateDebut) as dureetotale
from Client
join Location
on location.idClient = client.id
where Location.rendu = 'oui'

```

## Natalia :

### Liste des clients qui ont loué des livres et le nombre de livres distincts loués

```
SELECT C.id, C.nom, C.prenom, COUNT(DISTINCT L.isbnExemplaires) AS nbre_livres_empruntes
FROM Client C
JOIN Location L ON C.id = L.idClient
GROUP BY C.id, C.nom, C.prenom;

```
### Liste des livres (avec titre et ISBN) qui ont été loués au moins une fois

```
SELECT O.isbn, O.titre
FROM Ouvrage O
JOIN Exemplaires E ON O.isbn = E.isbn
JOIN Location L ON E.isbn = L.isbnExemplaires
GROUP BY O.isbn, O.titre;

```
### Liste des livres (avec titre et ISBN) qui n'ont jamais été loués

```
SELECT O.isbn, O.titre
FROM Ouvrage O
LEFT JOIN Exemplaires E ON O.isbn = E.isbn
LEFT JOIN Location L ON E.isbn = L.isbnExemplaires
WHERE L.id IS NULL;

```

### Liste des auteurs ayant au moins un ouvrage publié après l'an 2000

```
SELECT A.nom, A.prenom
FROM Auteur A
WHERE EXISTS (  
    SELECT 1
    FROM Ouvrage O
    WHERE A.id = O.idAuteur
    AND O.dateParution > '2000-01-01'
    );

```

### Liste des livres avec leur catégorie et le nombre d'exemplaires disponibles pour chaque livre

```
SELECT O.titre, C.libelle AS categorie, COUNT(E.idExemplaire) AS nombre_exemplaires
FROM Ouvrage O
JOIN Categorie C ON O.idCategorie = C.id
JOIN Exemplaires E ON O.isbn = E.isbn
GROUP BY O.titre, C.libelle;

```

## Dénice :

### Liste des catégories et le nombre d'ouvrages les concernant (catégories sans ouvrages comprises) triées par ordre croissant
```
SELECT Categorie.libelle,COUNT(idCategorie) AS nbre_ouvrages FROM Categorie 
LEFT JOIN Ouvrage ON Categorie.id=idCategorie 
GROUP BY libelle
ORDER BY nbre_ouvrages ASC;
```

### Liste des ouvrages et leur auteur dont l'époque de naissance est au 19ème siècle

```
SELECT O.titre,A.prenom,A.nom,A.dateNaissance FROM Ouvrage O
JOIN Auteur A ON O.idAuteur=A.id
WHERE A.dateNaissance LIKE "18%";
```

### Liste des clients ayant emprunté plus de 2 livres

```
SELECT C.id,C.nom,C.prenom,COUNT(C.id) AS nbre_livres_empruntes FROM Client C 
JOIN Location L ON C.id=L.idClient
WHERE EXISTS (SELECT idClient FROM Location)
GROUP BY C.id
HAVING nbre_livres_empruntes>2;
```

### Liste des clients ayant oublié de rendre leur livre entre la date limite et la date d'aujourd'hui avec le nom du livre

```
SELECT DISTINCT L.dateFin,C.prenom,C.nom,O.titre,L.isbnExemplaires,L.idExemplaire FROM Location L
JOIN Client C ON L.idClient=C.id
JOIN Exemplaires E ON L.isbnExemplaires=E.isbn
Join Ouvrage O ON E.isbn=O.isbn
WHERE L.dateFin<DATE(NOW()) AND L.rendu="Non";
```

## Kaleb :

### Liste des ouvrages avec leurs catégories et leurs auteurs
```
    SELECT O.titre, C.libelle AS “categorie”, A.nom AS “auteur”
    FROM Ouvrage O
    JOIN Categorie C ON O.idCategorie = C.id
    JOIN Auteur A ON O.idAuteur = A.id;
```

### Les clients ayant plus de 30 ans
```
    SELECT nom, prenom, age
    FROM Client
    WHERE age IN (SELECT age FROM Client WHERE age > 30);
```

### Les ouvrages qui n'ont pas d'exemplaire disponibles
```
    SELECT O.titre, O.isbn
    FROM Ouvrage O
    LEFT JOIN Exemplaires E ON O.isbn = E.isbn
    WHERE E.isbn IS NULL;
```

### Nombre total d'exemplaires pour chaque ouvrage
```
    SELECT O.titre, COUNT(E.isbn) AS “nombre_exemplaires”
    FROM Ouvrage O
    JOIN Exemplaires E ON O.isbn = E.isbn
    GROUP BY O.titre;
```

### Lister les auteurs ayant écrit au moins un ouvrage dans la catégorie 'Roman'
```
    SELECT A.nom, A.prenom
    FROM Auteur A
    WHERE EXISTS (  SELECT 1
                    FROM Ouvrage O
                    JOIN Categorie C ON O.idCategorie = C.id
                    WHERE A.id = O.idAuteur
                    AND C.libelle = 'Roman' );
```

### Somme des prix de tous les exemplaires disponibles pour chaque ouvrage
```
    SELECT O.titre, SUM(E.prix) AS “somme_prix_exemplaires”
    FROM Ouvrage O
    JOIN Exemplaires e ON O.isbn = E.isbn
    GROUP BY O.titre;
```


## Johan :

*Requêtes réalisées sur [bibliothequeMARIADB-johan.sql](./bibliothequeMARIADB-johan.sql)*


### Informations concernant les locations terminées dont l'exemplaire n'a pas été rendu et pour lesquelles le client habite à Toulouse.

```
SELECT location.id AS idLoc, exemplaires.id AS idExplr, ouvrage.titre, ouvrage.isbn, location.dateFin, client.id AS idClient, client.nom, client.prenom
FROM location 
JOIN client on client.id = location.idClient
JOIN exemplaires on exemplaires.isbnOuvrage=location.isbnOuvrage
JOIN ouvrage on ouvrage.isbn = exemplaireS.isbnOuvrage
WHERE client.ville='Toulouse'
AND location.rendu = 0
AND location.dateFin<CURRENT_DATE;
```

### Moyenne d'âges des clients qui n'ont pas rendu leur livre qui n'était pas de la catégorie Roman 

```
SELECT AVG(client.age) AS "Moyenne d'age non rendu"
FROM client
WHERE client.id NOT IN (SELECT client.id
						FROM client	
						JOIN location ON location.idClient = client.id
    					JOIN exemplaires ON exemplaires.id = location.idExemplaire
    					JOIN ouvrage ON ouvrage.isbn = exemplaires.isbnOuvrage
    					JOIN categorie ON categorie.id = ouvrage.idCategorie
					AND location.rendu=1
                                    AND categorie.libelle='Roman')
                            ;
```

### Liste des clients ayant loué un livre de Nietzsche en état Neuf et dont le nom commence par un 'N'

``` 
SELECT C.nom, C.prenom, C.id
FROM location L
JOIN client C on L.idClient = C.id
WHERE EXISTS (
						SELECT 1
						FROM location LL
						JOIN exemplaires E ON LL.idExemplaire=E.id
						JOIN ouvrage O ON E.isbnOuvrage = O.isbn
						JOIN auteur A on O.idAuteur = A.id
						WHERE E.etat = 'Neuf'
    					        AND A.nom = 'Nietzsche'
						AND LL.id=L.id)
AND C.nom like 'N%';
```


### Top 3 des exemplaires les plus loués et dans quelle ville ont ils ont le plus été loués.

```
SELECT E.id AS idExemplaire, O.titre, O.isbn, COUNT(L.id) AS nombre_locations,
       (SELECT C.ville
        FROM client C
        JOIN location L2 ON C.id = L2.idClient
        WHERE L2.idExemplaire = E.id
        GROUP BY C.ville
        ORDER BY COUNT(C.id) DESC
        LIMIT 1) AS ville_majoritaire
FROM exemplaires E
JOIN location L ON E.id = L.idExemplaire
JOIN ouvrage O ON E.isbnOuvrage = O.isbn
GROUP BY E.id, O.titre, O.isbn
ORDER BY nombre_locations DESC
LIMIT 3;

```


### Liste des auteurs n'ayant pas d'ouvrages enregistrés

```
SELECT A.*
FROM Auteur A
LEFT JOIN Ouvrage O ON O.idAuteur = A.id
WHERE O.isbn IS NULL;

```

# Schémas :

## Schéma Entité/association :

![Schéma E/A](Images/Schéma_Entité_Association.jpg)

## Schéma Relationnel :


**Categorie** (__id__, libelle)

**Ouvrage** (__isbn__, titre, dateParution, #idAuteur, #idCategorie)

**Auteur** (__id__, nom, prenom, dateNaissance, bio)

**Exemplaires** (__#isbn__, __idExemplaire__, etat)

**Location** (__id__, dateDebut, dateFin, rendu, #idClient, #isbnExemplaires, #idExemplaire)

**Client** (__id__, nom, prenom, age, ville, adresse, codePostal)


# Auto évaluation

## Natalia :

#### Niveau en SQL :

- [ ] débutant    
- [ ] intermédiaire   
- [x] avancé

#### Niveau d'implication :

- [ ] bas     
- [ ] moyen   
- [x] élevé


## Dénice :

#### Niveau en SQL :

- [ ] débutant    
- [ ] intermédiaire   
- [x] avancé

#### Niveau d'implication :

- [ ] bas     
- [ ] moyen   
- [x] élevé

## Kaleb :

#### Niveau en SQL :

- [ ] débutant    
- [ ] intermédiaire   
- [x] avancé

#### Niveau d'implication :

- [ ] bas     
- [ ] moyen   
- [x] élevé


## Angelo :

#### Niveau en SQL :

- [ ] débutant    
- [ ] intermédiaire   
- [x] avancé

#### Niveau d'implication :

- [ ] bas     
- [ ] moyen   
- [x] élevé


## Johan :

#### Niveau en SQL :

- [ ] débutant    
- [ ] intermédiaire   
- [x] avancé

#### Niveau d'implication :

- [ ] bas     
- [ ] moyen   
- [x] élevé

