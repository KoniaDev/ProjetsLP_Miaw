/*Prompt CHAT GPT 4

1 - Création de la BDD
(Schéma E/A)
Tu es un professionnel en création de bases de données et je veux que tu me génères la base visible sur le schéma entité association qui est joint
La table Categorie a pour clé primaire id qui est auto increment et son champ libelle est un enum de différents types d'ouvrages

La table auteur a pour clé primaire id qui est auto increment
nom prenom et bio qui sont des varchar, et dateNaissance qui stocke une date (tu choisiras le type approprié)

La table ouvrage a pour clé primaire isbn qui suit le modele 2-7654-1005-4 ou chaque chiffre peut être remplacé par un autre, à toi de choisir un type approprié,
Titre qui est un varchar, dateParution qui stocke une date, à toi de choisir le type, et en clés étrangères #idAuteur  qui réfère à auteur.id et #idCategorie qui réfère à categorie.id

La table exemplaires a pour clé primaire id en auto increment, un enum pour le champ etat qui liste les états possibles des exemplaires et en clé étrangère #isbnOuvrage qui réfère à la clé primaire de la table ouvrage

La table location a pour clé primaire id qui est auto increment, dateDebut et dateFin qui stockent une date, à toi de choisir leur type, #idClient en clé étrangère qui associe une location à un client par sa clé primaire client.id, #isbnOuvrage en clé étrangère sur l'isbn d'un examplaire pour savoir de quel livre il s'agit (exemplaire.#isbnOuvrage,  #idExemplaire qui réfère à examplaire.id, et un boolean du nom de rendu qui indique si l'exemplaire a été retourné

enfin, la table client qui a pour clé primaire id en auto increment, 
les champs nom prenom ville adresse qui sont des varchar 
age et codePostal qui sont des int

Chaque table aura sa première lettre en majuscule, chaque champ sera uniquement en minuscule, les requêtes attendues doivent s'executer sur MARIADB

*/

-- Création de la base de données
CREATE DATABASE IF NOT EXISTS Bibliotheque;
USE Bibliotheque;

-- Table Categorie
CREATE TABLE Categorie (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle ENUM('Roman', 'Essai', 'Poésie', 'Science-fiction', 'Biographie', 'Histoire', 'Art', 'Enfant', 'Cuisine')
);

-- Table Auteur
CREATE TABLE Auteur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255),
    prenom VARCHAR(255),
    dateNaissance DATE,
    bio TEXT
);

-- Table Ouvrage
CREATE TABLE Ouvrage (
    isbn VARCHAR(17) PRIMARY KEY, -- Format de l'ISBN: 2-7654-1005-4
    titre VARCHAR(255),
    dateParution DATE,
    idAuteur INT,
    idCategorie INT,
    FOREIGN KEY (idAuteur) REFERENCES Auteur(id),
    FOREIGN KEY (idCategorie) REFERENCES Categorie(id)
);

-- Table Exemplaires
CREATE TABLE Exemplaires (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etat ENUM('Neuf', 'Bon', 'Usé', 'Très Usé'),
    isbnOuvrage VARCHAR(17),
    FOREIGN KEY (isbnOuvrage) REFERENCES Ouvrage(isbn)
);

-- Table Client
CREATE TABLE Client (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255),
    prenom VARCHAR(255),
    age INT,
    ville VARCHAR(255),
    adresse VARCHAR(255),
    codePostal INT
);

-- Table Location
CREATE TABLE Location (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dateDebut DATE,
    dateFin DATE,
    rendu BOOLEAN,
    idClient INT,
    idExemplaire INT,
    isbnOuvrage VARCHAR(17),
    FOREIGN KEY (idClient) REFERENCES Client(id),
    FOREIGN KEY (idExemplaire) REFERENCES Exemplaires(id),
    FOREIGN KEY (isbnOuvrage) REFERENCES Exemplaires(isbnOuvrage)
);


/*Prompt CHAT GPT 4 

2- Création des inserts

Tu es un professionnel de gestion de base de données
Je veux que tu me génères des inserts qui me permettent d'obtenir des résultats quels que soit ma requête, autrement dit, les valeurs doivent utiliser tout le champ des possible de ma base de données en allant de valeurs tres completes et variées à des entrées comprenant des champs null quand c'est possible
La base est celle que tu viens de me générer, si tu ne l'as plus en mémoire la voici :
-- Création de la base de données
CREATE DATABASE IF NOT EXISTS BibliothequeMAN;
USE BibliothequeMAN;

-- Table Categorie
CREATE TABLE Categorie (
    id INT AUTO_INCREMENT PRIMARY KEY,
    libelle ENUM('Roman', 'Essai', 'Poésie', 'Science-fiction', 'Biographie', 'Histoire', 'Art', 'Enfant', 'Cuisine')
);

-- Table Auteur
CREATE TABLE Auteur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255),
    prenom VARCHAR(255),
    dateNaissance DATE,
    bio TEXT
);

-- Table Ouvrage
CREATE TABLE Ouvrage (
    isbn VARCHAR(17) PRIMARY KEY, -- Format de l'ISBN: 2-7654-1005-4
    titre VARCHAR(255),
    dateParution DATE,
    idAuteur INT,
    idCategorie INT,
    FOREIGN KEY (idAuteur) REFERENCES Auteur(id),
    FOREIGN KEY (idCategorie) REFERENCES Categorie(id)
);

-- Table Exemplaires
CREATE TABLE Exemplaires (
    id INT AUTO_INCREMENT PRIMARY KEY,
    etat ENUM('Neuf', 'Bon', 'Usé', 'Très Usé'),
    isbnOuvrage VARCHAR(17),
    FOREIGN KEY (isbnOuvrage) REFERENCES Ouvrage(isbn)
);

-- Table Client
CREATE TABLE Client (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255),
    prenom VARCHAR(255),
    age INT,
    ville VARCHAR(255),
    adresse VARCHAR(255),
    codePostal INT
);

-- Table Location
CREATE TABLE Location (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dateDebut DATE,
    dateFin DATE,
    rendu BOOLEAN,
    idClient INT,
    idExemplaire INT,
    isbnOuvrage VARCHAR(17),
    FOREIGN KEY (idClient) REFERENCES Client(id),
    FOREIGN KEY (idExemplaire) REFERENCES Exemplaires(id),
    FOREIGN KEY (isbnOuvrage) REFERENCES Exemplaires(isbnOuvrage)
);

Pour rappel ces inserts sont destinés à MARIADB
*/

INSERT INTO Categorie (libelle) VALUES 
('Roman'),
('Essai'),
('Poésie'),
('Science-fiction'),
('Biographie'),
('Histoire'),
('Art'),
('Enfant'),
('Cuisine');

INSERT INTO Auteur (nom, prenom, dateNaissance, bio) VALUES
('Hugo', 'Victor', '1802-02-26', 'Auteur de romans historiques et dramatiques.'),
('Asimov', 'Isaac', '1920-01-02', 'Père de la science-fiction moderne.'),
('Proust', 'Marcel', '1871-07-10', 'Écrivain français, auteur de À la recherche du temps perdu.'),
('Doe', 'John', '1985-05-15', NULL),
('Austen', 'Jane', '1775-12-16', 'Célèbre pour ses romans réalistes.'),
('Nietzsche', 'Friedrich', '1844-10-15', NULL);
('Canevet', 'Johan', '2000-08-17', NULL);

INSERT INTO Ouvrage (isbn, titre, dateParution, idAuteur, idCategorie) VALUES
('2-7654-1005-1', 'Les Misérables', '1862-06-30', 1, 1),
('2-7654-1005-2', 'Fondation', '1951-05-01', 2, 4),
('2-7654-1005-3', 'Du côté de chez Swann', '1913-11-14', 3, 1),
('2-7654-1005-4', 'Orgoglio e Pregiudizio', '1813-01-28', 5, 1),
('2-7654-1005-5', 'La généalogie de la morale', '1887-11-01', 6, 2),
('2-7654-1005-6', 'Lettres d’un inconnu', '2020-09-15', 4, 3);

INSERT INTO Exemplaires (etat, isbnOuvrage) VALUES
('Neuf', '2-7654-1005-1'),
('Bon', '2-7654-1005-2'),
('Usé', '2-7654-1005-3'),
('Très Usé', '2-7654-1005-4'),
('Neuf', '2-7654-1005-5'),
('Bon', '2-7654-1005-6');

INSERT INTO Client (nom, prenom, age, ville, adresse, codePostal) VALUES
('Martin', 'Pierre', 35, 'Paris', '123 Rue de la République', 75000),
('Dupont', 'Claire', 28, 'Lyon', '45 Avenue des Champs', 69000),
('Doe', 'Jane', NULL, 'Marseille', '56 Rue des Oliviers', 13000),
('Lemoine', 'Georges', 42, 'Toulouse', '10 Rue de la Garonne', 31000),
('Nguyen', 'Thi', 22, NULL, NULL, NULL),
('Perez', 'Carlos', 30, 'Lille', '78 Rue de la Liberté', 59000);

INSERT INTO Location (dateDebut, dateFin, rendu, idClient, idExemplaire, isbnOuvrage) VALUES
('2023-01-05', '2023-01-20', TRUE, 1, 1, '2-7654-1005-1'),
('2023-02-10', '2023-02-25', FALSE, 2, 2, '2-7654-1005-2'),
('2023-03-15', '2023-03-30', TRUE, 3, 3, '2-7654-1005-3'),
('2023-04-01', '2023-04-15', FALSE, 4, 4, '2-7654-1005-4'),
('2023-05-20', '2023-06-05', TRUE, 5, 5, '2-7654-1005-5'),
('2023-07-10', '2023-07-25', FALSE, 6, 6, '2-7654-1005-6');
('2022-01-05', '2022-01-20', TRUE, 1, 1, '2-7654-1005-1'),