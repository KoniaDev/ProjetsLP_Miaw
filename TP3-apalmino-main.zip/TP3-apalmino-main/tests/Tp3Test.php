<?php

namespace App\Tests;

use App\Repository\ConcertRepository;
use App\Repository\EmailRepository;
use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class Tp3Test extends WebTestCase
{
    public function testHomePage(): void
    {
        $client = static::createClient();
        $client->request('GET', '/');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('main.wrap>header>h2', 'Prochains concerts');
    }

    public function testNbConcertsPageAccueil(): void
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/');
        $this->assertResponseIsSuccessful();
        // test si le bon nombre de concerts actifs est bien sur /
        $concertRepository = static::getContainer()->get(ConcertRepository::class);
        $nbConcertsActifs = count($concertRepository->findAll());
        $this->assertCount($nbConcertsActifs, $crawler->filter('.evenement'));
    }

    public function testAdminPage(): void
    {
        $client = static::createClient();
        $client->request('GET', '/admin');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h1', 'Backoffice');
        $client->request('GET', '/admin/artiste');
        $this->assertResponseIsSuccessful();
        $client->request('GET', '/admin/concert');
        $this->assertResponseIsSuccessful();
    }

    public function testArtistePage(): void
    {
        $client = static::createClient();
        $client->request('GET', '/artistes');
        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h1', 'Ils sont passés à La Sirène !');
    }


    public function testNewsletter(): void
    {
        $client = static::createClient();
        $crawler = $client->request('GET', '/');
        $this->assertResponseIsSuccessful();
        $buttonCrawlerNode = $crawler->selectButton('ok');
        $form = $buttonCrawlerNode->form();
        $client->submit($form, [
            'newsletter[email]' => 'test@demo.local'
        ]);
        $emailRepository = static::getContainer()->get(EmailRepository::class);
        $email = $emailRepository->findBy(['email' => 'test@demo.local']);
        $this->assertCount(1, $email);
        if (count($email)>0) :
            $emailRepository->remove($email[0], true);
        endif;
    }

    /*
    public function testConnexionAdmin(): void
    {
        $client = static::createClient();
        $userRepository = static::getContainer()->get(UtilisateurRepository::class);
        $admin = $userRepository->findOneByUsername('admin');
        $client->loginUser($admin);
        $client->request('GET', '/admin');
        $this->assertResponseStatusCodeSame(302);
        $client->followRedirect();
        $this->assertSelectorTextContains('h1','Concert');

    }

    public function testConnexionUser(): void
    {
        $client = static::createClient();
        $userRepository = static::getContainer()->get(UtilisateurRepository::class);
        $user = $userRepository->findOneByUsername('user');
        $client->loginUser($user);
        $client->request('GET', '/admin');
        $this->assertResponseStatusCodeSame(403);
    }
    */

}
