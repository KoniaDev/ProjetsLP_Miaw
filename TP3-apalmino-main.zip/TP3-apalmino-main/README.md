# TP3 Symfony - Site de la Sirène

## Objectifs

- Mettre en production un site sous Symfony
- S'insérer dans un projet existant
- Corriger les bugs
- Configurer un back office avec EasyAdmin

## Préparation du poste de travail

Vous utiliserez votre machine personnelle en réutilisant la stack docker utilisé lors du premier TP.

La stack docker a été modifiée récemment, pensez à la mettre à jour.

```bash
# dans le dossier devPhpLp (WSL pour windows)
git pull
make updatePhp
```

## Utilisation de gitlabclassroom

Acceptez l'invitation pour le [tp de cette semaine](https://lpmiaw.univ-lr.fr/gitlabclassroom/assignment/01935966-b9e0-73f4-a23e-cfe5ee574ad9/accept).

En allant sur le [lien de la classe](https://gitlab.univ-lr.fr/lpmiaw-2024-2025/Symfony/TP3), vous devez voir votre projet sur lequel vous allez travailler.

## Réalisation

### ETQ gestionnaire, je veux un environnement commun à tous les développeurs

> Récupération du projet

```bash
# dans le dossier devPhpLp (WSL pour windows)
git clone git@gitlab.univ-lr.fr:lpmiaw-2024-2025/Symfony/TP3/TP3-{votre_login}.git projets/sftp3
```

J'ai modifié la stack docker pour gérer plus facilement les projets symfony à partir d'un clone. Voici comment procéder :

> Configuration du projet via la stack docker

```bash
# dossier devPhpLp (WSL pour windows)
make existingProject sftp3
```

Le projet va être analysé pour détecter le type de projet et créer la configuration nécessaire. Il aura une base de données associée et cela installera les dépendances automatiquement.

Fermer le terminal et lancez phpStorm pour ouvrir le dossier sftp3.

Ce projet reprend le site de la Sirène (salle de concert de La Rochelle). Il est déjà configuré pour fonctionner avec Symfony 7.

Il possède des entités ainsi que des fixtures pour les remplir.

```bash
make up
cd sftp3
bin/console doctrine:migrations:migrate # ou sf:d:m:m
bin/console doctrine:fixtures:load # ou sf d:f:l
```

Le site sous symfony doit s’afficher en tapant https://sftp3.localhost:8443 → Oups !

## ETQ développeur, je dois corriger les bugs…

Correction de bugs

> Création d'une nouvelle branche dans gitlab

Créez une nouvelle issue dans gitlab puis créer une branche manuellement pour corriger les problèmes.

> Détection des erreurs

Placez-vous sur la nouvelle branche.

Détectez les erreurs.

> Correction des erreurs

Modifiez le code afin de corriger les problèmes

> Tests et validation

Le site doit s’afficher correctement en local.

Faîtes le merge request.

Le test HomePage doit passer (voir dans Gitlab Classroom).

## ETQ chef de projet, je veux tester la mise en production de l’application

> Sur votre poste

Avant de mettre en production, vous aurez besoin d’un composant nécessaire sur votre projet symfony. Installez le composant ajoutant un .htaccess à votre projet pour que la réécriture d’adresses soit fonctionnelle.

**Attention**, il faut accepter **manuellement** la recette de ce composant, car c'est un composant de la communauté et non de Symfony.

```bash
composer req symfony/apache-pack
```

Actez cette modification sur git.

> Sur le serveur lpmiaw

Je vous ai créé pour l’occasion de ce TP, une nouvelle base de données appelée sftp3 préfixée de votre login_ (Allez voir sur le phpmyadmin du serveur lpmiaw !)

Faites un git clone de votre projet sur le serveur dans le dossier /work/home/{votre_login}/www/sftp3

Créez un fichier .env.local contenant les variables spécifiques à votre application (APP_ENV et DATABASE_URL)

Installez les dépendances php

Faites les migrations

Reprendre vos données de votre base de données locale. Vous ne pouvez pas utiliser les fixtures en production...

Vous pouvez utiliser la commande :

```bash
make dumpInsert sftp3
```

> Tests et validation

En pointant sur le dossier public de votre application symfony, votre site doit fonctionner.

Pour ne pas faire apparaître le dossier symfony, il faudrait créer un virtualhost ou un alias spécifique à votre application (vous ne pouvez pas le faire). 
Mais cela ressemblerait à ça :

```apache
# fichier de configuration d’apache
Alias /sftp3 /work/home/{votre_login}/www/sftp3/public/

<Directory "sftp3">
Order allow,deny
Allow from all
Options +Indexes
AllowOverride All
Require all granted
</Directory>
```

Si on voulait se passer du fichier .htaccess, il faudrait recopier son contenu dans la partie Directory ci-dessus.

## ETQ gestionnaire, je veux pouvoir administrer toutes les entités

> Installation du composant

```bash
composer req admin
```

> Configuration du bundle

Créez le dashboard ainsi que l’ensemble des classes crud de vos entités.

Voici le design à reproduire. 

![Design EasyAdmin](docs/images/easyadmin.png)

À implémenter : le filtre sur le tarif, la gestion des icônes pour les actions…

> Utilisation de routes plus explicites

- On veut pouvoir utiliser [des routes cohérentes](https://symfony.com/bundles/EasyAdminBundle/current/dashboards.html#pretty-admin-urls) pour la partie admin : /admin/artiste, /admin/concert... 

### Bonus

- On veut dissocier les concerts à venir des concerts passés. Pour cela, vous devrez gérer deux contrôleurs distincts et utiliser la fonction createIndexQueryBuilder.
- On ne peut pas ajouter de concerts passés. L’ajout d’un concert est divisé en deux parties à l’aide de colonnes et l’éditeur de texte pour la description est amélioré.
- On peut visualiser une miniature de la photo pour les artistes

> Tests et validation

En allant dans sur la route /admin, on peut gérer l’ensemble du site de manière conviviale.

Le test AdminPage doit passer (voir dans Gitlab Classroom).

## ETQ gestionnaire, je veux sécuriser le backoffice

Cette partie n’est pas complète. À vous de regarder le cours et la documentation associée.

> Installation du composant

```bash
composer req security
```

Normalement, cela n’ajoute rien, car le composant est une dépendance d’easyadmin.

> Ajout de l’entité Utilisateur

Un utilisateur peut se connecter à travers son username.

```bash
bin/console make:user
```

> Modification de l’entité Utilisateur

Un utilisateur possède également une adresse email, un nom, un prénom et une date de naissance.

```bash
bin/console make:entity Utilisateur
```

> Ajout du contrôleur de sécurité

```bash
bin/console make:security:form-login
```

> Ajout d’utilisateurs

Modifiez le fichier des fixtures afin d’ajouter deux utilisateurs à la base de données en chiffrant son mot de passe. Un utilisateur doit être admin et l’autre un simple user. Vous les nommerez "admin" et "user".

Relancez les fixtures.

> Tests et validation

Seul l’utilisateur admin pourra accéder à l’interface de gestion.

Enlever les commentaires dans la classe TP3Test.php sur les deux méthodes de connexions afin de tester cette nouvelle fonctionnalité.

Ces deux tests doivent passer (voir dans Gitlab Classroom).

## ETQ gestionnaire, je veux afficher les concerts par ordre chronologique.

> Modification des méthodes du Repository

Les concerts sont visibles sur la page d’accueil, mais ils ne sont pas triés par ordre chronologique.

Modifiez les méthodes du Repository afin de rendre actif ce tri.

> Tests et validation

En allant sur la page d’accueil, l’ensemble des concerts sont affichés par ordre chronologique.

## ETQ gestionnaire, je veux une page affichant l’ensemble des artistes

> Création d’une méthode dans le contrôleur

Ajoutez une méthode au contrôleur permettant de récupérer tous les artistes.

> Création de la vue associée

Créez une vue permettant d’afficher tous les artistes de manière appropriée. Le titre de la page sera "Ils sont passés à La Sirène !"

> Tests et validation

En allant sur la route /artistes, la liste des artistes avec leur photo qui ont déjà joué à La Sirène apparaît.

Le test ArtistePage doit passer (voir dans Gitlab Classroom).