    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area">
        <div class="container">
            <div class="row d-flex flex-wrap align-items-center">
                <div class="col-12 col-md-6">
                    <a href="#"><img src="img/core-img/logo.png" alt=""></a>
                </div>

                <div class="col-12 col-md-6">
                    <div class="footer-nav">
                        <ul>
                        <?php 
                                    wp_nav_menu(
                                        array('theme_location' => 'main_menu')
                                        );
                                    ?>
                            <!--<li><a href="index.html">Accueil</a></li>
                            <li><a href="page.html">Qui sommes-nous ?</a></li>
                            <li><a href="blog.html">Nouvelles</a></li>
                            <li><a href="page.html">Contact</a></li>-->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            
            <p><?= wp_count_posts('artiste')->publish; ?> artistes présents sur le site</p>
        </div>
    </footer>
    <!-- ##### Footer Area Start ##### -->

    <?php wp_footer(  ) ?>
    <!-- ##### All Javascript Script ##### -->
    <!-- jQuery-2.2.4 js -->
    
</body>

</html>