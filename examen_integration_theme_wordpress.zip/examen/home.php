<?php get_header() ?>
    <!-- ##### Blog Area Start ##### -->
    <div class="blog-area section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                <?php while(have_posts(  )): the_post(); ?>
                    <!-- Single Post Start -->
                    <div class="single-blog-post mb-100 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Post Thumb -->
                        <div class="blog-post-thumb mt-30">
                            <a href="<?php the_permalink(  ); ?>">
                            <?php if( has_post_thumbnail( )) : ?>
                                <?php the_post_thumbnail( ); ?>
                            <?php else : ?>
                                IMAGE PAR DEFAUT
                            <?php endif; ?>
                            </a>
                            <!-- Post Date -->
                            <div class="post-date">
                                <span><?php echo get_the_date('d')?></span>
                                <span><?php echo get_the_date('F Y')?></span>
                                <?php the_ID(  )?>
                            </div>
                        </div>

                        <!-- Blog Content -->
                        <div class="blog-content">
                            <!-- Post Title -->
                            <a href="<?php the_permalink(  ); ?>" class="post-title"><?php the_title(); ?></a>
                            <!-- Post Meta -->
                            <div class="post-meta d-flex mb-30">
                                <p class="post-author">Par<a href="#"> <?php the_author()?></a></p>
                                <p class="tags"><a href="#"><?php the_category(' - '); ?></a></p>
                                <p class="tags"><a href="#"><?= get_comments_number() ?> Commentaires</a></p>
                            </div>
                            <!-- Post Excerpt -->
                            <p><?php the_excerpt(); ?></p>
                        </div>
                    </div>
                    <?php endwhile ?>
                    
                </div>

                
            </div>
        </div>
    </div>
    <!-- ##### Blog Area End ##### -->

<?php get_footer() ?>