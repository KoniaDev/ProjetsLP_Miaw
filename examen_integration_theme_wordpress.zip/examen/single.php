<?php get_header() ?>
<!-- ##### Breadcumb Area Start ##### -->
<section class="breadcumb-area bg-img bg-overlay" style="background-image: url(<?= get_the_post_thumbnail_url()  ?>);">
<?php while (have_posts()) : the_post(); ?>
        <div class="bradcumbContent">
            <h2><?php the_title(); ?></h2>
        </div>
    </section>
    <!-- ##### Breadcumb Area End ##### -->

    <!-- ##### Content Area Start ##### -->
    <div class="container mb-100 mt-100">
        <p>
            <?php the_content(); ?>
        </p>
    </div>
    <?php comments_template()?>
    <!-- ##### Content Area End ##### -->
<?php endwhile ?>
<?php get_footer() ?>