<?php

add_theme_support( 'post-thumbnails' );

function wpdocs_theme_name_scripts() {
    wp_enqueue_style( 'style-main', get_template_directory_uri() . '/css/style.css' );
    wp_enqueue_script( 'script-jq', get_template_directory_uri() . '/js/jquery/jquery-2.2.4.min.js',
    array(), '1.0.0', true );
    wp_enqueue_script( 'script-boo', get_template_directory_uri() . '/js/bootstrap/bootstrap.min.js',
    array(), '1.0.0', true );
    wp_enqueue_script( 'script-pop', get_template_directory_uri() . '/js/bootstrap/popper.min.js',
    array(), '1.0.0', true );
    wp_enqueue_script( 'script-plug', get_template_directory_uri() . '/js/plugins/plugins.js',
    array(), '1.0.0', true );
    wp_enqueue_script( 'script-active', get_template_directory_uri() . '/js/active.js',
    array(), '1.0.0', true );
    }
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );
    
add_action('init', 'ajouter_menu');
function ajouter_menu() {
register_nav_menu('main_menu', 'Menu principal');
}

add_action( 'init', 'create_post_type' );
function create_post_type() {
register_post_type( 'artiste',
array(
'label' => 'Artistes',
'public' => true,
'supports' => array('title', 'editor', 'thumbnail')
)
);
}