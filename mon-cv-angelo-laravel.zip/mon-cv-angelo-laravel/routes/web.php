<?php

use App\Http\Controllers\BiographieController;
use App\Http\Controllers\ClubController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\CompetenceController;
use App\Http\Controllers\ProfileController;
use App\Models\Competence;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('/', [IndexController::class, 'index'])->name('home');


Route::get('/competence/create', [CompetenceController::class, 'create'])->name('competence.create'); 
//affiche le formulaire
Route::post('/competence/create', [CompetenceController::class, 'store']);
//route qu'empruntera le formulairepour l'enregistrementdes donnés
Route::get('/competence/update-{competence}', [CompetenceController::class, 'edit'])->name('competence.edit');//affiche le formulaire
Route::patch('/competence/update-{competence}', [CompetenceController::class, 'update']);//route qu'umpruntera le formulaire

Route::get('/competence/delete-{competence}', [CompetenceController::class, 'delete'])->name('competence.delete');
//affiche la page de confirmation
Route::delete('/competence/delete-{competence}', [CompetenceController::class, 'destroy']);
//requete pour supprimer les donnees

Route::get('/biographie', [BiographieController::class, 'index'])->name('biographie.index');
Route::get('/biographie/modifier-{biographie}', [BiographieController::class, 'edit'])->name('biographie.modifier'); //affiche leformulaire de modification
Route::patch('/biographie/modifier-{biographie}', [BiographieController::class, 'update']);//route vers la requette que va empreunter le formulaire pour etre envoyé


Route::get('/clubs', [ClubController::class, 'index'])->name('clubs.index');
Route::get('/club/create', [ClubController::class, 'create'])->name('club.create'); 
//affiche le formulaire
Route::post('/club/create', [ClubController::class, 'store']);
//route qu'empruntera le formulaire pour l'enregistrementdes donnés
Route::get('/club/modifier-{club}', [ClubController::class, 'edit'])->name('club.modifier'); 
//affiche leformulaire de modification
Route::patch('/club/modifier-{club}', [ClubController::class, 'update']);
//route vers la requette que va empreunter le formulaire pour etre envoyé
Route::get('/club/delete-{club}', [ClubController::class, 'delete'])->name('club.supprimer');
//affiche la page de confirmation
Route::delete('/club/delete-{club}', [ClubController::class, 'destroy']);
//requete pour supprimer les donnees
Route::get('/club-{club}', [ClubController::class, 'show'])->name('club.show');





require __DIR__.'/auth.php';
