<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <a href="<?php echo e(route('clubs.index')); ?>">Clubs</a>
    <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\Angelo\Desktop\laravel\mon-cv-angelo\resources\views/base.blade.php ENDPATH**/ ?>