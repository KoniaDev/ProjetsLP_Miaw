
<link href="<?php echo e(url('storage/css/style.css')); ?>"rel="stylesheet">
<?php $__env->startSection('title', 'Clubs'); ?>
<?php if(session('success')): ?>
    <div style="background-color: green"><?php echo e(session('success')); ?></div>  
<?php endif; ?>
<?php $__env->startSection('content'); ?>
 <h1>Clubs</h1>
 <a href="<?php echo e(route('club.create')); ?>">Ajouter un club</a>
 <ul>
    <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li> 
        <a href="<?php echo e(route('club.modifier', $club->slug)); ?>">Modifier</a>
        <a href="<?php echo e(route('club.supprimer', $club->slug)); ?>">Supprimer</a>
        <a href="<?php echo e(route('club.show', $club->slug)); ?>">Afficher</a>
        <?php echo e($club->nom); ?> | <?php echo e($club->stade); ?> | <?php echo e($club->slug); ?>

    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Angelo\Desktop\laravel\mon-cv-angelo\resources\views/club/index.blade.php ENDPATH**/ ?>