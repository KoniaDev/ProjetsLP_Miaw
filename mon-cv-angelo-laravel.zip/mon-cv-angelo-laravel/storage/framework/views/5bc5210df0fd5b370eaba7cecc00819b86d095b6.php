

<?php $__env->startSection('title', 'Supprimer'); ?>
<link href="<?php echo e(url('storage/css/style.css')); ?>"rel="stylesheet">
<?php $__env->startSection('content'); ?>
 <h1>Supprimer</h1>
    <h2><?php echo e($club->nom); ?> ?</h2>
    <form action="" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("DELETE"); ?>
        <div>
            <button>Supprimer</button>
        </div>
    </form>
    <a href="<?php echo e(route('clubs.index')); ?>"><button>Annuler</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Angelo\Desktop\laravel\mon-cv-angelo\resources\views/club/delete.blade.php ENDPATH**/ ?>