

<?php $__env->startSection('title', "Modification Club"); ?>
<link href="<?php echo e(url('storage/css/style.css')); ?>"rel="stylesheet">
<?php $__env->startSection('content'); ?>
 <h1>Modification de Club</h1>
<form action="" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PATCH'); ?>
    <div>
        <span>Nom</span>
        <input type="text" name="nom" value="<?php echo e(old('nom', $club->nom)); ?>">
        <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <span>stade</span>
        <input type="text" name="stade" value="<?php echo e(old('stade', $club->stade)); ?>">
        <?php $__errorArgs = ['stade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <span>slug</span>
        <input type="text" name="slug" value="<?php echo e(old('slug', $club->slug)); ?>">
        <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <button>Modifier</button> 
    </div>
</form>
<a href="<?php echo e(route('home')); ?>">Accueil</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Angelo\Desktop\laravel\mon-cv-angelo\resources\views/club/edit.blade.php ENDPATH**/ ?>