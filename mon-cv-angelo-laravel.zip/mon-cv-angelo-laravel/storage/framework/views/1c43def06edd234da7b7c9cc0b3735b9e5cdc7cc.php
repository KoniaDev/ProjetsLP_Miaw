
<link href="<?php echo e(url('storage/css/style.css')); ?>"rel="stylesheet">

<?php $__env->startSection('title', 'Ma biographie'); ?>
<?php if(session('success')): ?>
    <div style="background-color: greenyellow"><?php echo e(session('success')); ?></div>  
<?php endif; ?>
<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $biographies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $biographie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('biographie.modifier', $biographie->id)); ?>">Modifier la biographie</a> <br> <br>
        <h1><?php echo e($biographie->titre); ?></h1> <br> <?php echo e($biographie->description); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Angelo\Desktop\laravel\mon-cv-angelo\resources\views/biographie/index.blade.php ENDPATH**/ ?>