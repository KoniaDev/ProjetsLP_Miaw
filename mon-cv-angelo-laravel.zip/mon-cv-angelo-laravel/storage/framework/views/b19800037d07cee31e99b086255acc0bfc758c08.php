

<?php $__env->startSection('title', 'Supprimer'); ?>

<?php $__env->startSection('content'); ?>
 <h1>Supprimer</h1>
    <?php echo e($competence->nom); ?> <?php echo e($competence->description); ?> 
    <form action="" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field("DELETE"); ?>
        <div>
            <button>Supprimer</button>
            
        </div>
    </form>
    <a href="<?php echo e(route('home')); ?>"><button>Annuler</button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Angelo\Desktop\laravel\mon-cv-angelo\resources\views/competence/delete.blade.php ENDPATH**/ ?>