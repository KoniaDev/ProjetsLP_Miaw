

<?php $__env->startSection('title', 'Mon CV'); ?>
<?php if(session('success')): ?>
    <div style="background-color: greenyellow"><?php echo e(session('success')); ?></div>  
<?php endif; ?>
<?php $__env->startSection('content'); ?>
 <h1>Competences</h1>
 <a href="<?php echo e(route('competence.create')); ?>">Ajouter une compétence</a>
 <ul>
    <?php $__currentLoopData = $competences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>  
        <?php echo e($competence->nom); ?> <?php echo e($competence->description); ?>

        <a href="<?php echo e(route('competence.edit', $competence->id)); ?>">Modifier</a>
        <a href="<?php echo e(route('competence.delete', $competence->id)); ?>">Supprimer</a>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Angelo\Desktop\laravel\mon-cv-angelo\resources\views/index/home.blade.php ENDPATH**/ ?>