
<link href="<?php echo e(url('storage/css/style.css')); ?>"rel="stylesheet">
<?php $__env->startSection('title', 'Clubs'); ?>

<?php $__env->startSection('content'); ?>
 <h1>Club</h1>
    <?php echo e($club->nom); ?> <?php echo e($club->stade); ?> <?php echo e($club->slug); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Angelo\Desktop\laravel\mon-cv-angelo\resources\views/club/show.blade.php ENDPATH**/ ?>