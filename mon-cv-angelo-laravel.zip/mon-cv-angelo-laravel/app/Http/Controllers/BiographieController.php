<?php

namespace App\Http\Controllers;

use App\Http\Requests\ValidationBiographieRequest;
use App\Models\Biographie;
use Illuminate\Http\Request;

class BiographieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $biographies = Biographie::all();
        return view('biographie.index', compact("biographies"));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Biographie  $biographie
     * @return \Illuminate\Http\Response
     */
    public function show(Biographie $biographie)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Biographie  $biographie
     * @return \Illuminate\Http\Response
     */
    public function edit(Biographie $biographie)// permets d'afficher le formulaire
    {
        return view("biographie.edit", compact("biographie"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Biographie  $biographie
     * @return \Illuminate\Http\Response
     */
    public function update(ValidationBiographieRequest $request, Biographie $biographie)
    {
        //NE SURTOUT PAS OUBLIER LE ValidatonBiographieRequest CREE PRECEDEMENT

        {
            $datas = $request->validated();
            $biographie->update($datas);
                    return redirect()
                        ->route('biographie.index')
                        ->with('success', "La competence à bien ete enregistrée");
        }
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Biographie  $biographie
     * @return \Illuminate\Http\Response
     */
    public function destroy(Biographie $biographie)
    {
        //
    }
}
