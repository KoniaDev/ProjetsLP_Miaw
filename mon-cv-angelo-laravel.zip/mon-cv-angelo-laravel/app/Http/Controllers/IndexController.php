<?php

namespace App\Http\Controllers;

use App\Models\Competence;
use Illuminate\Http\Request;
use App\Http\Controllers\CompetenceController;

class IndexController extends Controller{

    public function index(Request $request){
        $competences = app(CompetenceController::class)->index(); //injection dependence
        return view('index.home', compact('competences'));
    }

}