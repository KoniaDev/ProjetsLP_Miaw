@extends('base')

@section('title', 'Supprimer')
<link href="{{url('storage/css/style.css')}}"rel="stylesheet">
@section('content')
 <h1>Supprimer</h1>
    <h2>{{$club->nom}} ?</h2>
    <form action="" method="POST">
        @csrf
        @method("DELETE")
        <div>
            <button>Supprimer</button>
        </div>
    </form>
    <a href="{{route('clubs.index')}}"><button>Annuler</button></a>
@endsection