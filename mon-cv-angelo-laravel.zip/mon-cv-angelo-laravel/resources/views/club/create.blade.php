@extends('base')

@section('title', 'Ajouter Club')
<link href="{{url('storage/css/style.css')}}"rel="stylesheet">
@section('content')
 <h1>Ajouter un club</h1>
<form action="" method="post">
    @csrf
    <div>
        <span>Nom</span>
        <input type="text" name="nom" >
        @error('nom')
            {{$message}}
        @enderror
    </div>
    <div>
        <span>Slug</span>
        <input type="text" name="slug">
        @error('slug')
            {{$message}}
        @enderror
    </div>
    <div>
        <span>Stade</span>
        <input type="text" name="stade">
        @error('stade')
            {{$message}}
        @enderror
    </div>
    <div>
        <span>Logo</span>
        <input type="file" name="logo">
        @error('logo')
            {{$message}}
        @enderror
    </div>
    
    <div>
        <button>ajouter</button>
    </div>
</form>
<a href="{{route('clubs.index')}}">Accueil</a>
@endsection