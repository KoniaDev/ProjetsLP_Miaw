@extends('base')

@section('title', "Modification Club")
<link href="{{url('storage/css/style.css')}}"rel="stylesheet">
@section('content')
 <h1>Modification de Club</h1>
<form action="" method="post">
    @csrf
    @method('PATCH')
    <div>
        <span>Nom</span>
        <input type="text" name="nom" value="{{old('nom', $club->nom)}}">
        @error('nom')
            {{$message}}
        @enderror
    </div>
    <div>
        <span>stade</span>
        <input type="text" name="stade" value="{{old('stade', $club->stade)}}">
        @error('stade')
            {{$message}}
        @enderror
    </div>
    <div>
        <span>slug</span>
        <input type="text" name="slug" value="{{old('slug', $club->slug)}}">
        @error('slug')
            {{$message}}
        @enderror
    </div>
    <div>
        <button>Modifier</button> 
    </div>
</form>
<a href="{{route('home')}}">Accueil</a>
@endsection