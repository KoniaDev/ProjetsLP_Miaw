@extends('base')
<link href="{{url('storage/css/style.css')}}"rel="stylesheet">
@section('title', 'Clubs')
@if(session('success'))
    <div style="background-color: green">{{session('success')}}</div>  
@endif
@section('content')
 <h1>Clubs</h1>
 <a href="{{route('club.create')}}">Ajouter un club</a>
 <ul>
    @foreach($clubs as $club)
    <li> 
        <a href="{{route('club.modifier', $club->slug)}}">Modifier</a>
        <a href="{{route('club.supprimer', $club->slug)}}">Supprimer</a>
        <a href="{{route('club.show', $club->slug)}}">Afficher</a>
        {{$club->nom}} | {{$club->stade}} | {{$club->slug}}
    </li>
    @endforeach
 </ul>
@endsection