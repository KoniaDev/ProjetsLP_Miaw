@extends('base')
<link href="{{url('storage/css/style.css')}}"rel="stylesheet">
@section('title', 'Clubs')

@section('content')
 <h1>Club</h1>
    {{$club->nom}} {{$club->stade}} {{$club->slug}}
@endsection