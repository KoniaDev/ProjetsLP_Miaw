@extends('base')

@section('title', 'Mon CV')
@if(session('success'))
    <div style="background-color: greenyellow">{{session('success')}}</div>  
@endif
@section('content')
 <h1>Competences</h1>
 <a href="{{route('competence.create')}}">Ajouter une compétence</a>
 <ul>
    @foreach($competences as $competence)
    <li>  
        {{$competence->nom}} {{$competence->description}}
        <a href="{{route('competence.edit', $competence->id)}}">Modifier</a>
        <a href="{{route('competence.delete', $competence->id)}}">Supprimer</a>
    </li>
    @endforeach
 </ul>
@endsection