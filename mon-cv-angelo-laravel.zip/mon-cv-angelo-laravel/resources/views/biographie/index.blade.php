@extends('base')
<link href="{{url('storage/css/style.css')}}"rel="stylesheet">

@section('title', 'Ma biographie')
@if(session('success'))
    <div style="background-color: greenyellow">{{session('success')}}</div>  
@endif
@section('content')

    @foreach($biographies as $biographie)
    <a href="{{route('biographie.modifier', $biographie->id)}}">Modifier la biographie</a> <br> <br>
        <h1>{{$biographie->titre}}</h1> <br> {{$biographie->description}}
    @endforeach
@endsection