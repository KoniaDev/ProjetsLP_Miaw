@extends('base')

@section('title', "Modification biographie")

@section('content')
 <h1>Modification de biographie</h1>
<form action="" method="post">
    @csrf
    @method('PATCH')
    <div>
        <span>Nom</span>
        <input type="text" name="titre" value="{{old('titre', $biographie->titre)}}">
        @error('titre')
            {{$message}}
        @enderror
    </div>
    <div>
        <span>description</span>
        <input type="text" name="description" value="{{old('description', $biographie->description)}}">
        @error('titre')
            {{$message}}
        @enderror
    </div>
    <div>
        <button>Modifier</button> 
    </div>
</form>
<a href="{{route('home')}}">Accueil</a>
@endsection