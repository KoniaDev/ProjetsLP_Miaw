@extends('base')

@section('title', "Modification competence")

@section('content')
 <h1>Modification de competence</h1>
<form action="" method="post">
    @csrf
    @method('PATCH')
    <div>
        <span>Nom</span>
        <input type="text" name="nom" value="{{old('nom', $competence->nom)}}">
        @error('nom')
            {{$message}}
        @enderror
    </div>
    <div>
        <span>description</span>
        <input type="text" name="description" value="{{old('description', $competence->description)}}">
        @error('nom')
            {{$message}}
        @enderror
    </div>
    <div>
        <button>Modifier</button> 
    </div>
</form>
<a href="{{route('home')}}">Accueil</a>
@endsection