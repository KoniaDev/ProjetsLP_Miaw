@extends('base')

@section('title', 'Supprimer')

@section('content')
 <h1>Supprimer</h1>
    {{$competence->nom}} {{$competence->description}} 
    <form action="" method="POST">
        @csrf
        @method("DELETE")
        <div>
            <button>Supprimer</button>
            
        </div>
    </form>
    <a href="{{route('home')}}"><button>Annuler</button></a>
@endsection